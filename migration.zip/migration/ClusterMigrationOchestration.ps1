[CmdletBinding()]
Param(
	[Parameter(Mandatory=$true)]
	[string]$SourceVC,
	
	[Parameter(Mandatory=$false)]
	[string]$DestinationVC,
	
	[Parameter(Mandatory=$true)]
	[string]$ClusterName,
	
	[Parameter(Mandatory=$true)]
	[PSCredential]$RootCredential = (Get-Credential),
	
	[Parameter(Mandatory=$true)]
	$DestinationContainer,
	
	[Parameter(Mandatory=$false)]
	[string[]]$VDSToMigrateNames,
	
	[Parameter(Mandatory=$false)]
	[String]$VDSExportPath = ".\",
	
	[Parameter(Mandatory=$false)]
	[boolean]$CreateVDSOnDestination = $true,
	
	[Parameter(Mandatory=$false)]
	[boolean]$KeepVDSIdentifiers = $false
)



## Pre-execution header/disclaimer
Write-Host "Date: $(Get-Date)"
If (($global:defaultviservers | where {$_.isconnected}).count -lt 2) {
	Write-Host "Currently connected to less than 2 (two) VI Servers. Exiting"
	Return -1
}
If (($global:defaultciservers | where {$_.isconnected}).count -lt 2) {
	Write-Host "Currently connected to less than 2 (two) CI Servers."
	$promptAnswer = read-host "Enter (Y/y) to continue or anything else to stop execution"
	If ($promptAnswer.toUpper() -ne 'Y') {
		Write-Host "User cancelled execution. Exiting script."
		Return -1000
	}
}
Write-Host "Connected to the following VIServers:"
($global:defaultviservers | where {$_.isconnected}).name -join " | "
Write-Host "`nConnected to the following CIServers:"
($global:defaultciservers | where {$_.isconnected}).name -join " | "
Write-Host "`nThis script will affect all hosts from and VMs in Cluster [$($ClusterName)] in vCenter [$($sourceVC)]"
# Write-Host "Do you wish to view the affected items summarization?"
# $promptAnswer = read-host "Enter (L/l) to list or anything else to continue execution"
# If ($promptAnswer.toUpper() -ne 'L') {
	# Write-Host "Execution summary:"
	# ...
# }

Write-Host "Are you sure you wish to continue?"
$promptAnswer = read-host "Enter (Y/y) to continue or anything else to stop execution"
If ($promptAnswer.toUpper() -ne 'Y') {
	Write-Host "User cancelled execution. Exiting script."
	Return -1000
}

$sourceCluster = Get-Cluster -Name $ClusterName -Server $SourceVC
If ($sourceCluster.Count -ne 1) {
	Write-Host "More than one (1) cluster was found on [$($SourceVC)]"
	Return -3
}

Write-Verbose "Found cluster [$($sourceCluster.Name)]"

$sourceVMHostCol = Get-VMHost -Location $sourceCluster
$sourceVMCol = Get-VM -Location $sourceCluster -ErrorAction SilentlyContinue
$sourceNetAdaptersCol = Get-NetworkAdapter -VM $sourceVMCol -ErrorAction SilentlyContinue

$sourceVDSCol = @()
If ($VDSToMigrateNames.count -gt 0) {
	ForEach ($VDSToMigrateName in $VDSToMigrateNames) {
		$sourceVDS = $null
		$sourceVDS = Get-VDSwitch -Name $VDSToMigrateName -Server $SourceVC
		If ($sourceVDS.Count -ne 1) {
			Write-Host "None or more than one (1) VDS named [$($VDSToMigrateName)] was found in vCenter: [$($SourceVC)]"
			Return -4
		}
		$SourceVDSCol += $SourceVDS
	}
} Else {
	$sourceVDSCol = Get-VDSwitch -VMHost $sourceVMHostCol[0] -ErrorAction SilentlyContinue
	If (-not $sourceVDSCol) {
		Write-Host "No VDS was found, connected to $($sourceVMHostCol[0].Name) in vCenter: [$($SourceVC)]"
		Write-Host "Are you sure you wish to continue with NO VDS's to be migrated?"
		$promptAnswer = read-host "Enter (Y/y) to continue or anything else to stop execution"
		If ($promptAnswer.toUpper() -ne 'Y') {
			Write-Host "User cancelled execution. Exiting script."
			Return -1000
		}
	}
}

If (-not $KeepVDSIdentifiers -and ($sourceVDSCol.Count -gt 0)) {
	Write-Host "Using $($sourceVMHostCol[0].Name) as a reference to determine host vmnic/uplink mappings to VDS switches."
	$referenceProxySwitches = $sourceVMHostCol[0].ExtensionData.Config.Network.ProxySwitch
	$referenceProxySwitchesWithConnectedVmnics = $referenceProxySwitches | where {$_.spec.backing.pnicspec.pnicdevice.count -gt 0}
	ForEach ($ProxyVDS in $referenceProxySwitchesWithConnectedVmnics) {
		If ($sourceVDSCol.Name -notcontains $ProxyVDS.DVSName) {
			Write-Host "Host $($sourceVMHostCol[0].Name) seems to have a physical adapter connected to a switch no specified on the parameters."
			Write-Verbose "[$($ProxyVDS.DVSName)] is not part of the specified VDS switches."
			Return -5
		}
	}

	$vDSToVmnicMapping = @()
	## This is inneficient (basically the reverse of a loop made before) but done so, for readability
	ForEach ($sourceVDS in $sourceVDSCol) {
		$mappingProps = @{}
		$mappingProps.VDSName = $sourceVDS.Name
		$pSwitch = $null
		$pSwitch = $referenceProxySwitchesWithConnectedVmnics | Where {$_.DVSName -eq $sourceVDS.Name}
		$mappingProps.Vmnics = $pSwitch.spec.backing.pnicspec.pnicdevice
		$mapping = New-Object -TypeName PSObject -Prop $mappingProps
		$vDSToVmnicMapping += $mapping
	}
	$vDSToVmnicMapping | fl

	$pgsToVmkMapping = @()
	ForEach ($vmk in (Get-VMHostNetworkAdapter -VMKernel -VMHost $sourceVMHostCol[0])) {
		$mappingProps = @{}
		If ($vmk.PortGroupName -like "dvportgroup-[0-9]*") {
			$mappingProps.PGName = (Get-VDPortgroup -ID "DistributedVirtualPortgroup-$($vmk.PortGroupName)" -Server $SourceVC).Name
		} Else { $mappingProps.PGName = $vmk.PortGroupName }
		$mappingProps.VDSName = (Get-VDPortgroup -Name $mappingProps.PGName -VDSwitch $sourceVDSCol).VDSwitch.Name
		$mappingProps.VMK = $vmk.name
		$mapping = New-Object -TypeName PSObject -Prop $mappingProps
		$pgsToVmkMapping += $mapping
	}
	$pgsToVmkMapping | fl
}

## Get cluster location if cluster location is string
If ($DestinationContainer.gettype().fullname -like "*string*") {
	If ($DestinationVC) {
		$result = Get-View -ViewType Datacenter -Filter @{Name="^$DestinationContainer$"} -ErrorAction SilentlyContinue -Server $DestinationVC
		If ($result.count -eq 1) { 
			$DestinationContainer = $result | Get-VIObjectByVIView 
			$dc = $DestinationContainer
		}
		ElseIf ($result.count -eq 0) {
			
			$result = Get-View -ViewType Folder -Filter @{Name="^$DestinationContainer$"} -ErrorAction SilentlyContinue -Server $DestinationVC | where {$_.ChildType -contains "ComputeResource"}
			If ($result.count -eq 1) { 
				$DestinationContainer = $result | Get-VIObjectByVIView 
				$dc = GetFolderDC -folder $DestinationContainer
			}
			ElseIf ($result.count -eq 0) {
				Write-Host "No valid container was found. Datacenters and Host Folders are the only valid containers."
				Return -6
			} Else {
				Write-Host "More than one (1) container was found."
				Return -6
			}
		}
		Else {
			Write-Host "More than one (1) container was found."
			Return -6
		}
	} Else {
		Write-Host "If DestinationContainer is a string, DestinationVC must be set"
		Return -6
	}
}
Write-Verbose "[$($DestinationContainer.Name)], on vCenter $($DetinationVC) is of type [$($DestinationContainer.Gettype().Name)]"

Write-Verbose "Creating cluster with name $($sourceCluster.Name) on location $($DestinationContainer.Name), on vCenter $($DetinationVC)"


$destinationCluster = New-Cluster -Server $DestinationVC -Name $sourceCluster.Name -Location $DestinationContainer
$destinationCluster = Get-Cluster -Name $sourceCluster.Name -Server $DestinationVC
If ($sourceCluster.HAEnabled) {
	Set-Cluster -Cluster $destinationCluster -HAEnabled $sourceCluster.HAEnabled -Confirm:$false
	If ($sourceCluster.HAAdmissionControlEnabled) {
		Set-Cluster -Cluster $destinationCluster -HAAdmissionControlEnabled $sourceCluster.HAAdmissionControlEnabled -Confirm:$false
	}
}
If ($sourceCluster.DrsEnabled) {
	Set-Cluster -Cluster $destinationCluster -DrsEnabled $sourceCluster.DrsEnabled -Confirm:$false
	Set-Cluster -Cluster $destinationCluster -DrsAutomationLevel $sourceCluster.DrsAutomationLevel -Confirm:$false
}
$destinationCluster = Get-Cluster -Name $sourceCluster.Name -Server $DestinationVC

If ($destinationCluster.count -ne 1) {
	Write-Host "There was an error creating a cluster named [$($sourceCluster.Name)] in vCenter [$($DestinationVC)]"
	return -7
}
Write-Host "Cluster [$($destinationCluster.Name)] created on vCenter [$($DestinationVC)]"
Write-Host "Are you sure you wish to continue?"
$promptAnswer = read-host "Enter (Y/y) to continue or anything else to stop execution"
If ($promptAnswer.toUpper() -ne 'Y') {
	Write-Host "User cancelled execution. Exiting script."
	Return -1000
}

MigrateVMHostToAnotherVCenter -VMHostNames $sourceVMHostCol.Name -DestinationVC $DestinationVC -DestinationClusterName $destinationCluster -RootCredential $RootCredential
While ($sourceVMHostCol.Count -ne $destinationVMHostCol.Count) { 
	$destinationVMHostCol = Get-VMHost -Location $destinationCluster | Where {$_.ConnectionState -like "Connected"}
	Sleep 20
}

Write-Host "Hosts should have been added to [$($destinationCluster.Name)]. Are you sure you wish to continue?"
$promptAnswer = read-host "Enter (Y/y) to continue or anything else to stop execution"
If ($promptAnswer.toUpper() -ne 'Y') {
	Write-Host "User cancelled execution. Exiting script."
	Return -1000
}

$destinationVDSCol = @()
## Again, this is inneficient, still, done for readability and also decoupling of each iteration
If ($CreateVDSOnDestination) {
	ForEach ($sourceVDS in $sourceVDSCol) {
		$sourceVDS
		$vdsExportFullPath = "$($VDSExportPath)\$($sourceVDS.Name).zip"
		$vdsExportFullPath
		Export-VDSwitch -VDSwitch $sourceVDS -Destination $vdsExportFullPath
		If ($KeepVDSIdentifiers) {
			New-VDSwitch -Server $DestinationVC -KeepIdentifiers -Location $dc -BackupPath $vdsExportFullPath
		} Else {
			New-VDSwitch -Server $DestinationVC -Location $dc -BackupPath $vdsExportFullPath
		}
		$vds = $null
		$vds = Get-VDSwitch -Server $DestinationVC -Name $sourceVDS.Name
		If (-not $vds) {
			Write-Host "[$($sourceVDS.Name)] was not created correctly on [$($DestinationVC)]"
			Return -7
		}
		$destinationVDSCol += $vds
	}
}

Write-Host "Any exported VDS's should have been imported by now. Are you sure you wish to continue?"
$promptAnswer = read-host "Enter (Y/y) to continue or anything else to stop execution"
If ($promptAnswer.toUpper() -ne 'Y') {
	Write-Host "User cancelled execution. Exiting script."
	Return -1000
}

If (-not $KeepVDSIdentifiers -and ($sourceVDSCol.Count -gt 0)) {
	
	ForEach ($vds in $destinationVDSCol) {
		$vmnicsString = ($vDSToVmnicMapping | where {$_.VDSName -eq $vds.Name}).Vmnics
		$vmksString = ($pgsToVmkMapping | where {$_.VDSName -eq $vds.Name}).VMK
		$pgsString = ($pgsToVmkMapping | where {$_.VDSName -eq $vds.Name}).PGName
		$sourceVDS = Get-VDSwitch -Name $vds.Name -Server $SourceVC
		$vmsOnSourceVDS = $sourceVDS | Get-VM
		$vmsOnSourceVDSToMigrate = $sourceVMCol | where {$vmsOnSourceVDS.Name -contains $_.name}
		
		Write-Host "The below will be migrated in order!!!"
		Write-Host "VMNICS     					: $($vmnicsString -join '; ')"
		Write-Host "VMKs       					: $($vmksString -join '; ')"
		Write-Host "Port Groups					: $($pgsString -join '; ')"
		Write-Host "Total VM Number on this VDS : $($vmsOnSourceVDSToMigrate.Count)"
		Write-Host "Are you sure you wish to continue?"
		$promptAnswer = read-host "Enter (Y/y) to continue or anything else to stop execution"
		If ($promptAnswer.toUpper() -ne 'Y') {
			Write-Host "User cancelled execution. Exiting script."
			Return -1000
		}
		
		#This will make VMs unavailable depending on VDS migrated
		#This needs to be changed so that $sourceVMCol is VDS specific
		MigrateHostToVDS -VMHosts $destinationVMHostCol -ReferenceVMs $vmsOnSourceVDSToMigrate -DestinationVDS $vds -VmnicNames $vmnicsString -VmkernelNames $vmksString -PGNames $pgsString
	}
} Else {
	ForEach ($referenceVM in $sourceVMCol) {
		$VM = Get-VM -Name $referenceVM.Name -Server $DestinationVC
		$VM.ExtensionData.Reload()
	}
}