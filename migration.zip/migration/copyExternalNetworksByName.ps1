[CmdletBinding()]
Param(
	[Parameter(Mandatory=$true)]
	[string]$SourceVC,
	
	[Parameter(Mandatory=$true)]
	[string]$DestinationVC,
	
	[Parameter(Mandatory=$true)]
	[string]$SourceCI,
	
	[Parameter(Mandatory=$true)]
	[string]$DestinationCI,
	
	[Parameter(Mandatory=$true)]
	[string[]]$ExternalNetworkNames
)

ForEach ($ExternalNetworkName in $ExternalNetworkNames) {
	
	$refExternalNetwork = Get-ExternalNetwork -Name $ExternalNetworkName -Server $SourceCI
	copyVCloudExternalNetwork -ReferenceExternalNetwork $refExternalNetwork -destinationCIServer $DestinationCI -sourceVIServer $SourceVC `
	 -destinationVIServer $DestinationVC

}