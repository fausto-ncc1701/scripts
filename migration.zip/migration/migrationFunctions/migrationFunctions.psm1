function GetServerFromUid {
	Param (
		[Parameter(Mandatory=$true)]
		$Object	
	)
	If ($Object.uid -like "") {Return $null}
	[void]($Object.uid -match '@[^:]*')
	$matches[0].Trim('@')
	
<#
	.SYNOPSIS

	Gets the server name from the UID property of some PowerCLI provided object types.

	.DESCRIPTION

	Parses the UID property of a PowerCLI object, and returns the server name as string.

	.PARAMETER Object
	Specifies the object from which the server name should be retrieved.


	.OUTPUTS

	System.String. Returns a string or empty string with the server name

	.EXAMPLE

	C:\PS> GetServerFromUid -Object (Get-VM VM01)
#>
}

function GetCIServerAdminFromServerName {
	Param (
		[Parameter(Mandatory=$true)]
		[string]$CIServer	
	)
	$CIServerView = ($global:defaultciservers | where {$_.name -like $CIServer}).ExtensionData
	$CIServerView.GetAdmin()
}

function GetCIServerAdminExtensionFromServerName {
	Param (
		[Parameter(Mandatory=$true)]
		[string]$CIServer	
	)
	$CIServerView = ($global:defaultciservers | where {$_.name -like $CIServer}).ExtensionData
	$CIServerAdmin = $CIServerView.GetAdmin()
	$CIServerAdmin.GetExtension()
}

function GetOrgVDCAvailableNetworksFromOrgVDC {
	Param (
		[Parameter(Mandatory=$true)]
		$Object	
	)
	$Object.ExtensionData.AvailableNetworks.Network
	
<#
	.SYNOPSIS

	Lists all available networks on a Org vDC object from the vCloud API.

	.DESCRIPTION

	Acesses the Network property from an Org VDC's ExtensionData, AvailableNetworks
	
	.PARAMETER Object
	A vCloud Org VDC object.

	.OUTPUTS

	Array of Org VDC Network references.

	.EXAMPLE

	C:\PS> GetOrgVDCAvailableNetworksFromOrgVDC -Object (Get-OrgVDC OvDC01)
#>
}

function GetDVPGMoRefValueFromOrgVDCNetwork {
	Param (
		[Parameter(Mandatory=$true)]
		$Object	
	)
	If ($Object.ProviderInfo -like "") {Return $null}
	[void]($Object.ProviderInfo -match ":[^ ]*")
	$matches[0].Trim(':')
	
<#
	.SYNOPSIS

	Retrieves the MoRef of a vSphere Distributed Virtual Port Group, from an Org VDC Network
	object, backed by and External Network.

	.DESCRIPTION

	Parses the ProviderInfo porperty of an Org VDC Network object from the vCloud API,
	for the MoRef value of the associated distributed port group.
	
	.PARAMETER Object
	A vCloud Org VDC Network object.

	.OUTPUTS

	System.String. MoRef value of a distributed port group.

	.EXAMPLE

	C:\PS> GetDVPGMoRefValueFromOrgVDCNetwork -Object (Get-OrgVDCNetwork OvDC01_Net01)
#>
	
}

function SetStoragePolicyOnVM {
	Param (
		[Parameter(Mandatory=$true)]
		$VM,
		
		[Parameter(Mandatory=$true)]
		$StoragePolicy,

		[Parameter(Mandatory=$true)]
		$VIServer			
	)
	$VM = Get-VM -Name $VM -Server $VIServer
	$HDCol = Get-HardDisk -VM $VM
	
	$SPolicy = Get-SpbmStoragePolicy -Name $StoragePolicy -Server $VIServer 
	
	Set-SpbmEntityConfiguration $VM, $HDCol -StoragePolicy $SPolicy

	
	
	}

function GetCIVMIdStringFromCIVM {
	Param (
		[Parameter(Mandatory=$true)]
		$CIVM	
	)
	[void]($CIVM.ExtensionData.id -match "[^:]*$")
	$idString = $matches[0]
	$idString

<#
	.SYNOPSIS

	Retrieves the Id of a vCloud Virtual Machine.

	.DESCRIPTION

	Parses a vCloud Virtual Machine's id property to return a string.
	
	.PARAMETER CIVM
	A vCloud Virtual Machine object.

	.OUTPUTS

	System.String. Id dstring from a vCloud Virtual Machine. Usually attached as a suffix
	to a vSphere Virtual Machine's name, that is being managed by vCloud.

	.EXAMPLE

	C:\PS> GetCIVMIdStringFromCIVM -CIVM (Get-CIVM CIVM01)
#>	
	
}

function GetVIVMFromCIVMBById {
	Param (
		[Parameter(Mandatory=$true)]
		$CIVM	
	)
	
	$idString = GetCIVMIdStringFromCIVM -CIVM $CIVM
	$VIVM = Get-View -ViewType VirtualMachine -Filter @{'Name'=$idString} | Get-VIObjectByVIView
	$VIVM
	
<#
	.SYNOPSIS

	Retrieves a vSphere Virtual Machine by using the Id property of a vCloud Virtual Machine.

	.DESCRIPTION

	Searches vSphere Virtual Machines that contain in its name the Id string of a 
	given vCloud Virtual Machine.
	
	.PARAMETER CIVM
	A vCloud Virtual Machine object.

	.OUTPUTS

	A vSphere Virtual Machine object which contains the input's CIVM id in its name string.

	.EXAMPLE

	C:\PS> GetVIVMFromCIVMBById -CIVM (Get-CIVM CIVM01)
#>	
}

function ProtectedGetFolderParent {
	Param(
		[Parameter(Mandatory=$true)]
		[VMware.VimAutomation.ViCore.Impl.V1.Inventory.FolderImpl]$childFolder
	)
	
	$sourceServer = GetServerFromUid -Object $childFolder
	Get-Folder -Id $childFolder.parentId -Server $sourceServer
	
	
}
	
function ProtectedGetFullPath {
	Param (
		[Parameter(Mandatory=$true)]
		[VMware.VimAutomation.ViCore.Impl.V1.Inventory.FolderImpl]$folder,
		
		[Parameter(Mandatory=$true)]
		[boolean]$withDC=$false
	)
	
	$sourceServer = GetServerFromUid -Object $folder
	If (($folder.Parent -like "vm") -or ($folder.Parent -like "host") -or ($folder.Parent -like "network") -or ($folder.Parent -like "datastore")) {
		If (-not $withDC) {$fullPath =  $folder.Name + "\"}
		Else {$fullPath =  $folder.Parent.Parent.Name + "\" + $folder.Name + "\"}
		$fullPath
	}
	Else {
		$parent = ProtectedGetFolderParent -childFolder $folder 
		$fullPath  = (ProtectedGetFullPath -folder $parent -withDC $withDC) + $folder.Name + "\"
		$fullPath
	}
}

function GetFolderDC {
	Param (
		[Parameter(Mandatory=$true)]
		[VMware.VimAutomation.ViCore.Impl.V1.Inventory.FolderImpl]$folder
	)
	
	$sourceServer = GetServerFromUid -Object $folder
	$fullPathWithDC = ProtectedGetFullPath -folder $folder -withDC:$true
	$dcName = ($fullPathWithDC.Split('\'))[0]
	$dc = Get-Datacenter -Name $dcName -server $sourceServer
	$dc
}

function GetFolderPath {
	Param (
		[Parameter(Mandatory=$true)]
		[VMware.VimAutomation.ViCore.Impl.V1.Inventory.FolderImpl]$folder,
		
		[Parameter(Mandatory=$false)]
		[boolean]$withDC=$false
	)
	
	$sourceServer = GetServerFromUid -Object $folder
	$strPath = ProtectedGetFullPath -folder $folder -withDC $withDC
	$strPath.TrimEnd('\')
}

function CreateVCloudExternalNetwork {
	Param(
	  [Parameter(Mandatory=$True,Position=1)]
	   [string]$DestinationCI,
		
	   [Parameter(Mandatory=$True)]
	   [string]$DestinationVI,
	   
	   [Parameter(Mandatory=$True)]
	   [string]$PortGroupName,
	   
	   [Parameter(Mandatory=$True)]
	   [string]$ExternalNetworkName,
	   
	   [Parameter(Mandatory=$False)]
	   [string]$ExternalNetworkDescription = "None",
	   
	   [Parameter(Mandatory=$False)]
	   [string]$ExternalNetworkIPScopeDNS1,
	   
	   [Parameter(Mandatory=$False)]
	   [string]$ExternalNetworkIPScopeDNS2,
	   
	   [Parameter(Mandatory=$False)]
	   [string]$ExternalNetworkIPScopeDNSSuffix,
	   
	   [Parameter(Mandatory=$True)]
	   [string]$ExternalNetworkIPScopeGW,
	   
	   [Parameter(Mandatory=$True)]
	   [string]$ExternalNetworkIPScopeMask,
	   
	   [Parameter(Mandatory=$True)]
	   [string]$ExternalNetworkIPScopeStartAddress,
	   
	   [Parameter(Mandatory=$True)]
	   [string]$ExternalNetworkIPScopeEndAddress
	   
	)

	$CIServerAdminExtension = GetCIServerAdminExtensionFromServerName -CIServer DestinationCI

	$NewExternalNetwork = new-object vmware.vimautomation.cloud.views.VMWExternalNetwork
	$NewExternalNetwork.Name = $ExternalNetworkName
	$NewExternalNetwork.Description = $ExternalNetworkDescription

	$vCenterCIView = $CIServerAdminExtension.getVimServerReferences().VimServerReference.GetCIView()
	$dvpg = get-view -viewtype DistributedVirtualPortGroup -Server $DestinationVI | where {$_.name -like $PortGroupName}

	write-host "vCenter href: "$vCenterCIView.href
	write-host "dvPG Key: " $dvPG.key

	$NewExternalNetwork.VimPortGroupRef = new-object VMware.VimAutomation.Cloud.Views.VimObjectRef

	$NewExternalNetwork.VimPortGroupRef.MoRef = $dvPG.key
	#$mynetwork.VimPortGroupRef.VimObjectType = "NETWORK"
	$NewExternalNetwork.VimPortGroupRef.VimObjectType = "DV_PORTGROUP"

	$NewExternalNetwork.VimPortGroupRef.VimServerRef = new-object VMware.VimAutomation.Cloud.Views.Reference
	$NewExternalNetwork.VimPortGroupRef.VimServerRef.href = $vCenterCIView.href
	#$mynetwork.VimPortGroupRef.VimServerRef.type = "application/vnd.vmware.admin.vmwvirtualcenter+xml"

	$NewExternalNetwork.Configuration = new-object VMware.VimAutomation.Cloud.Views.NetworkConfiguration
	$NewExternalNetwork.configuration.fencemode = "isolated"

	$NewExternalNetwork.Configuration.IpScopes = new-object VMware.VimAutomation.Cloud.Views.IpScopes
	$NewExternalNetwork.Configuration.IpScopes.IpScope = new-object VMware.VimAutomation.Cloud.Views.IpScope
	$NewExternalNetwork.Configuration.IpScopes.ipscope[0].Gateway = $ExternalNetworkIPScopeGW
	$NewExternalNetwork.Configuration.IpScopes.ipscope[0].Netmask = $ExternalNetworkIPScopeMask
	$NewExternalNetwork.Configuration.IpScopes.ipscope[0].IsInherited = "False"
	If ($ExternalNetworkIPScopeDNS1) {$NewExternalNetwork.Configuration.IpScopes.ipscope[0].Dns1 = $ExternalNetworkIPScopeDNS1}
	If ($ExternalNetworkIPScopeDNS2) {$NewExternalNetwork.Configuration.IpScopes.ipscope[0].Dns2 = $ExternalNetworkIPScopeDNS2}
	If ($ExternalNetworkIPScopeDNSSuffix) {$NewExternalNetwork.Configuration.IpScopes.ipscope[0].DnsSuffix = $ExternalNetworkIPScopeDNSSuffix}
	

	$NewExternalNetwork.Configuration.IpScopes.ipscope[0].ipranges = new-object vmware.vimautomation.cloud.views.ipranges
	$NewExternalNetwork.Configuration.Ipscopes.ipscope[0].ipranges.iprange = new-object vmware.vimautomation.cloud.views.iprange
	$NewExternalNetwork.Configuration.IpScopes.ipscope[0].IpRanges.IpRange[0].startaddress = $ExternalNetworkIPScopeStartAddress
	$NewExternalNetwork.Configuration.IpScopes.ipscope[0].IpRanges.IpRange[0].endaddress = $ExternalNetworkIPScopeEndAddress

	$result = $CIServerAdminExtension.CreateExternalNet($NewExternalNetwork)
	$result

<#
	.SYNOPSIS

	Create a vCloud External Network, backed by a vSphere distributed virtual port group.

	.DESCRIPTION

	Takes string inputs to create an External Network on a vCloud Director server, using a
	vSphere distributed virtual port group as backing.
	
	.PARAMETER DestinationCI
	The name of a vCloud Director Server to which there is a currently active connection
	
	.PARAMETER DestinationVI
	The name of a vCenter Server to which there is a currently active connection.
	
	.PARAMETER PortGroupName
	The name of a vSphere port group on the DestinationVIServer
	
	.PARAMETER ExternalNetworkName
	The name of the External Network to be created.
	
	.PARAMETER ExternalNetworkDescription
	The description of the External Network to be created.
	
	.PARAMETER ExternalNetworkIPScopeDNS1
	Primary DNS server for the external network's IP Scope.
	
	.PARAMETER ExternalNetworkIPScopeDNS2
	Secondary DNS server for the external network's IP Scope.
	
	.PARAMETER ExternalNetworkIPScopeDNSSuffix
	DNS suffix to be attached to connections on this IP Scope.
	
	.PARAMETER ExternalNetworkIPScopeGW
	Gateway for this network's IP Scope.
	
	.PARAMETER ExternalNetworkIPScopeMask
	Mask for this network's IP Scope.
	
	.PARAMETER ExternalNetworkIPScopeStartAddress
	First IP address on the IP range of this network's IP Scope.
	
	.PARAMETER ExternalNetworkIPScopeEndAddress
	Last IP address on the IP range of this network's IP Scope.
	
	.OUTPUTS
	
	VMware.VimAutomation.Cloud.Views.VMWExternalNetwork. Outputs the created External Network.
	
	.EXAMPLE

	CreateVCloudExternalNetwork -DestinationCI "vcd-server01" -DestinationVI "vi-server01" -PortGroupName "PG_DVPG01" -ExternalNetworkName "Ext_DVPG01" -ExternalNetworkDescription "External Network for PG_DVPG01" -ExternalNetworkIPScopeDNS1 "192.168.0.201" -ExternalNetworkIPScopeDNS2 "192.168.0.202" -ExternalNetworkIPScopeDNSSuffix "corp.local" -ExternalNetworkIPScopeGW "192.168.1.254" -ExternalNetworkIPScopeMask "255.255.255.128" -ExternalNetworkIPScopeStartAddress "192.168.1.129" -ExternalNetworkIPScopeEndAddress "192.168.1.150"
	Create a vCloud External Network named Ext_DVPG01
#>	
}

function copyVCloudExternalNetwork {
	Param(
		[Parameter(Mandatory=$True,Position=1)]
		$ReferenceExternalNetwork,

		[Parameter(Mandatory=$True)]
		[string]$DestinationCI,

		[Parameter(Mandatory=$True)]
		[string]$SourceVI,

		[Parameter(Mandatory=$True)]
		[string]$DestinationVI,

		[Parameter(Mandatory=$False)]
		[string]$ExternalNetworkName,

		[Parameter(Mandatory=$False)]
		[string]$ExternalNetworkDescription
	   
	)

	#This function can only copy direct external networks which have Ipscopes defined
	#No exception handling is done
	
	$CIServerAdminExtension = GetCIServerAdminExtensionFromServerName -CIServer $DestinationCI

	$NewExternalNetwork = new-object vmware.vimautomation.cloud.views.VMWExternalNetwork
	If ($ExternalNetworkName) {	$NewExternalNetwork.Name = $ExternalNetworkName }
	Else { $NewExternalNetwork.Name = $ReferenceExternalNetwork.Name }
	
	If ($ExternalNetworkDescription) { $NewExternalNetwork.Description = $ExternalNetworkDescription }
	Else { $NewExternalNetwork.Description = $ReferenceExternalNetwork.Description }
	
	$srcvdpid = "DistributedVirtualPortgroup-$($ReferenceExternalNetwork.ExtensionData.VimPortGroupRef.MoRef)"
	$srcdvpg = Get-VDPortGroup -Id $srcvdpid -Server $SourceVI
	$vCenterCIView = $CIServerAdminExtension.getVimServerReferences().VimServerReference.GetCIView()
	$dvpg = get-view -viewtype DistributedVirtualPortGroup -Server $DestinationVI -Filter @{Name="^$($srcdvpg.name)$"}
	
	write-verbose "source PG name: $($srcdvpg.name)"
	write-verbose "vCenter href: $($vCenterCIView.href)"
	write-verbose "dvPG Key: $($dvPG.key)"

	$NewExternalNetwork.VimPortGroupRef = new-object VMware.VimAutomation.Cloud.Views.VimObjectRef

	$NewExternalNetwork.VimPortGroupRef.MoRef = $dvPG.MoRef.Value
	#$mynetwork.VimPortGroupRef.VimObjectType = "NETWORK"
	$NewExternalNetwork.VimPortGroupRef.VimObjectType = "DV_PORTGROUP"

	$NewExternalNetwork.VimPortGroupRef.VimServerRef = new-object VMware.VimAutomation.Cloud.Views.Reference
	$NewExternalNetwork.VimPortGroupRef.VimServerRef.href = $vCenterCIView.href
	#$mynetwork.VimPortGroupRef.VimServerRef.type = "application/vnd.vmware.admin.vmwvirtualcenter+xml"

	$NewExternalNetwork.Configuration = new-object VMware.VimAutomation.Cloud.Views.NetworkConfiguration
	$NewExternalNetwork.configuration.fencemode = "isolated"
	
	$NewExternalNetwork.Configuration.IpScopes = $ReferenceExternalNetwork.ExtensionData.Configuration.IpScopes
	$result = $CIServerAdminExtension.CreateExternalNet($NewExternalNetwork)
	$result
	
<#
	.SYNOPSIS

	Create a vCloud External Network, backed by a vSphere distributed virtual port group, by copying properties
	from a reference External Network object.

	.DESCRIPTION

	Creates an External Network on a given vCloud Director, by taking as input a reference External Network,
	copying its basic properties such as Name, Description, backing port group name and IPScope configuration.
	Inlcudes parameters to override the External Network name and description.
	
	.PARAMETER ReferenceExternalNetwork
	A vCloud External Network object, used as reference for the creation of a new one.
	
	.PARAMETER DestinationCI
	The name of a vCloud Director Server to which there is a currently active connection
	
	.PARAMETER SourceVI
	The name of a vCenter Server to which there is a currently active connection and contains the backing for the ReferenceExternalNetwork.
	
	.PARAMETER DestinationVI
	The name of a vCenter Server to which there is a currently active connection and contains the backing for the External Network to be created.
	
	.PARAMETER ExternalNetworkName
	The name of the External Network to be created. Optional parameter, possibly overriding the ReferenceExternalNetwork name.
	
	.PARAMETER ExternalNetworkDescription
	The description of the External Network to be created. Optional parameter, possibly overriding the ReferenceExternalNetwork description.
	
	.OUTPUTS
	
	VMware.VimAutomation.Cloud.Views.VMWExternalNetwork. Outputs the created External Network.
	
	.EXAMPLE

	copyVCloudExternalNetwork -ReferenceExternalNetwork (Get-ExternalNetwork -Name "Ext_DVPG01" -server "vcd-server01") -DestinationCI "vcd-server02" -SourceVI "vi-server01" -DestinationVI "vi-server02" -ExternalNetworkName "Ext_New-DVPG01" -ExternalNetworkDescription "New External Network for PG_DVPG01" 
	Create a vCloud External Network, using External Network "Ext_DVPG01" as reference, overriding its name and description
	
	.EXAMPLE

	copyVCloudExternalNetwork -ReferenceExternalNetwork (Get-ExternalNetwork -Name "Ext_DVPG01" -server "vcd-server01") -DestinationCI "vcd-server02" -SourceVI "vi-server01" -DestinationVI "vi-server02" 
	Create a vCloud External Network, using External Network "Ext_DVPG01" as reference, maintaining the same name and description
	
#>
}

function copyOrg {
	Param(
		[Parameter(Mandatory=$True,Position=1)]
		$ReferenceOrg,
		
		[Parameter(Mandatory=$True)]
		[string]$DestinationCI
	)
	
	$CIServerAdmin = GetCIServerAdminFromServerName -CIServer $DestinationCI
	
	$orgSpec = New-Object -TypeName VMware.VimAutomation.Cloud.Views.AdminOrg
	$orgSpec.FullName = $ReferenceOrg.FullName
	$orgSpec.Description = $ReferenceOrg.Description
	$orgSpec.Name = $ReferenceOrg.Name
	
	$orgSpec.Settings = $ReferenceOrg.ExtensionData.Settings
	
	$CIServerAdmin.CreateOrg($orgSpec)
	# New-Org -Name $ReferenceOrg.Name -Description $ReferenceOrg.Description -Fullname $ReferenceOrg.FullName -Server $DestinationCI
	
<#
	.SYNOPSIS

	Creates a vCloud Organization by using another Organization as reference.

	.DESCRIPTION

	Intended to help migrating objects between vCloud Director instances, this function copies the Name, FullName,
	Description and Settings properties of a reference Organization, and creates a new Organization on a desired
	vCloud Director server, using these copied properties.
	
	.PARAMETER ReferenceOrg
	A vCloud Organization object, used as reference for the creation of a new one.
	
	.PARAMETER DestinationCI
	The name of a vCloud Director Server to which there is a currently active connection, on which the new Organization will be created.
	
	.OUTPUTS
	
	VMware.VimAutomation.Cloud.Views.AdminOrg. Outputs the created Organization.
	
	.EXAMPLE

	copyOrg -ReferenceOrg (Get-Org -Name "Org01" -server "vcd-server01") -DestinationCI "vcd-server02" -SourceVIServer "vi-server01" -DestinationVIServer "vi-server02" -ExternalNetworkName "Ext_New-DVPG01" -ExternalNetworkDescription "New External Network for PG_DVPG01" 
	Create a vCloud External Network, using External Network "Ext_DVPG01" as reference, overriding its name and description
	
#>	
}

## Use this method to create a ProviderVDC after adding hosts to a VC
## that is registered with the desired vCD
function createProviderVDC {
	Param(	   
	   [Parameter(Mandatory=$True)]
	   [string]$DestinationCI,
		
	   [Parameter(Mandatory=$True)]
	   [string]$ResourcePoolName,
	   
	   [Parameter(Mandatory=$True)]
	   [string]$ProviderVDCName,
	   
	   [Parameter(Mandatory=$False)]
	   [string]$DefaultUser,
	   
	   [Parameter(Mandatory=$False)]
	   [string]$DefaultPassword,
	   
	   [Parameter(Mandatory=$False)]
	   [string]$HighestSupportedHardwareVersion	= "vmx-11",
	   
	   [Parameter(Mandatory=$False)]
	   [string[]]$StoragePolicyNames = "*"
	   
	)
	
	$CIServerAdminExtension = GetCIServerAdminExtensionFromServerName -CIServer $DestinationCI
	
	$VimServerReference = $CIServerAdminExtension.getvimserverreferences().vimserverreference
	If ($VimServerReference.count -ne 1) {
		Write-Host "None or more than 1 VimServerReference was found."
		Return -1
	}
	$VimExtension = get-ciview -id $vimServerReference.href -server $DestinationCI
	$ResPoolList = $VimExtension.GetResourcePoolList()
	$ReferenceResPool = $ResPoolList.ResourcePool | where {$_.Name -eq $ResourcePoolName}
	If ($ReferenceResPool.Count -ne 1) {
		Write-Host "More than one (1) resource pool was found. Verify if resource pools exists or remove multiple instances."
		Write-Verbose "Resource Pools found: $($ReferencesResPool.Name -join ' | ')"
		Write-Verbose "Resource Pools moRef: $($ReferencesResPool.moRef -join ' | ')"
		Return -1
	}
	$ResPoolRefs = New-Object VMware.VimAutomation.Cloud.Views.VimObjectRefs
	$ResPoolRef = New-Object VMware.VimAutomation.Cloud.Views.VimObjectRef
	$ResPoolRef.VimServerRef = $VimServerReference[0]
	$ResPoolRef.MoRef = $ReferenceResPool.MoRef
	$ResPoolRef.VimObjectType = $ReferenceResPool.VimObjectType
	$ResPoolRefs.VimObjectRef += $ResPoolRef
	
	$PvDCParams = New-Object VMware.VimAutomation.Cloud.Views.VMWProviderVdcParams
	$PvDCParams.IsEnabled = $true
	$PvDCParams.VimServer = $VimServerReference[0]
	$PvDCParams.Name = $ProviderVDCName
	If ($DefaultUser) { $PvDCParams.DefaultUsername = $DefaultUser }
	If ($DefaultPassword) { $PvDCParams.Defaultpassword = $DefaultPassword }
	If ($HighestSupportedHardwareVersion) { $PvDCParams.HighestSupportedHardwareVersion = $HighestSupportedHardwareVersion }
	ForEach ($StoragePolicyName in $StoragePolicyNames) {
		$PvDCParams.StorageProfile += $StoragePolicyName
	}
	$PvDCParams.ResourcePoolRefs = $ResPoolRefs
	
	$CIServerAdminExtension.CreateProvidervdcsparam($PvDCParams)
	
<#
	.SYNOPSIS

	Creates a vCloud Director Provider vDC 

	.DESCRIPTION

	Creates a Provider vDC on a given vCloud Director, using the vCloud API /admin/extension/providervdcsparams
	operation. You can specify the Provider vDC name, use the name of a vSphere resource pool or cluster to be associated to
	xthe Provider vDC, default user and password for preparing the hosts, highest virtual hardware version supported and
	the names of Storage Policies available to the Provider vDC.
	
	.PARAMETER DestinationCI
	The name of a vCloud Director Server to which there is a currently active connection
	
	.PARAMETER ResourcePoolName
	The name of a vSphere Cluster or Resource Pool that will provide the resources backing this new Provider vDC.
	This should be an uniquely named Resource Pool or cluster that resides on a vCenter connected to the destination
	vCloud Director server (see -DestinationCI).
	
	.PARAMETER ProviderVDCName
	The name of the Provider vDC to be created.
	
	.PARAMETER DefaultUser
	Default user account to be used when preparing or performing other operations on the hosts of this Provider vDC.
	
	.PARAMETER DefaultPassword
	Default password associated withe the -DefaultUser, to be used when preparing or performing other operations on the hosts of this Provider vDC.
	
	.PARAMETER HighestSupportedHardwareVersion
	The maximum supported virtual hardware version to be used on this Provider vDC. 
	Following the format: 'vmx-11' (For hardware version 11)
	
	.PARAMETER StoragePolicyNames
	String array for the name of the storage policies available to this Provider vDC.
	
	.OUTPUTS
	
	VMware.VimAutomation.Cloud.Views.ProviderVDC. Outputs the created Provider vDC Object.
	
	.EXAMPLE

	createProviderVDC -DestinationCI "vcd-server02" -ResourcePoolName "Cluster_CL01" -ProviderVDCName "PvDC01" -DefaultUser "root" -DefaultPassword "passw0rd" -HighestSupportedHardwareVersion "vmx-10" -StoragePolicyNames ("StoragePolicy-SAS","StoragePolicy-SSD-")
	Creates a Provider vDC, backed by vSphere cluster: Cluster_CL01, located in a vCenter connected to vCloud Director "vcd-server02"
	
#>
}

## Use this method, if needed, to prepare hosts of a given Provider VDC
Function PrepareCIHost { 
    Param (
		
		[Parameter(Mandatory=$True)]
		$CIServer,
        
		[Parameter(Mandatory=$True)]
		[String]$Username, 
        
		[Parameter(Mandatory=$True)]
		[String]$Password, 
        
		[Parameter(Mandatory=$True)]
		[String]$HostName 
    ) 
	
    $Search = Search-cloud -QueryType Host -Name $HostName -Server $CIServer
    $HostView = Get-CIView -SearchResult $Search 
    $HostView.Prepare($password, $username) 

}

function createOrgVDC {
	Param(	   
	   [Parameter(Mandatory=$True)]
	   $Org,
	   
	   [Parameter(Mandatory=$True)]
	   $ProviderVDC,
		
	   [Parameter(Mandatory=$True)]
	   [string]$OvDCName,
	   
	   [Parameter(Mandatory=$False)]
	   [string]$OvDCDescription,
	   
	   [Parameter(Mandatory=$True)]
	   [ValidateSet("AllocationVApp","AllocationPool ","ReservationPool")]
	   [String]$AllocationModel,
	   
	   [Parameter(Mandatory=$False)]
	   [string[]]$OvDCStoragePolicyNames = "*",
	   
	   [Parameter(Mandatory=$False)]
	   [int]$OvDCStorageProfileLimit = 0,
	   
	   [Parameter(Mandatory=$False)]
	   [int]$OvDCCPUAllocated = 0,
	   
	   [Parameter(Mandatory=$False)]
	   [int]$OvDCCPULimit = 0,
	   
	   [Parameter(Mandatory=$False)]
	   [int]$OvDCMemAllocated = 0,
	   
	   [Parameter(Mandatory=$False)]
	   [int]$OvDCMemLimit = 0,
	   
	   [Parameter(Mandatory=$False)]
	   [double]$GuaranteedCPU,
	   
	   [Parameter(Mandatory=$False)]
	   [double]$GuaranteedMem,
	   
	   [Parameter(Mandatory=$False)]
	   [double]$VCpuInMhz,
	   
	   [Parameter(Mandatory=$False)]
	   [int]$VMQuota,
	   
	   [Parameter(Mandatory=$False)]
	   [int]$NetworkQuota,
	   
	   [Parameter(Mandatory=$False)]
	   [int]$NicQuota,
	   
	   [Parameter(Mandatory=$False)]
	   [Boolean]$FastProvision = $true,
	   
	   [Parameter(Mandatory=$False)]
	   [Boolean]$OverCommitAllowed,
	   
	   [Parameter(Mandatory=$False)]
	   [Boolean]$ThinProvisioned = $true
	   
	)
	
	$CIServer = getServerFromUid $Org
	
	$OvDCParams = New-Object VMware.VimAutomation.Cloud.Views.CreateVdcParams
	$OvDCParams.Name = $OvDCName 
	$OvDCParams.Description = $OvDCDescription 
	$OvDCParams.AllocationModel = $AllocationModel 
	$OvDCParams.ProviderVdcReference = $ProviderVDC.href 
	
	$OvDCParams.ResourceGuaranteedCpu =  $GuaranteedCPU
	$OvDCParams.ResourceGuaranteedMemory = $GuaranteedMem
	If ($VCpuInMhz) { $OvDCParams.VCpuInMhz = $VCpuInMhz }
	$OvDCParams.VMQuota = $VMQuota 
	$OvDCParams.NetworkQuota = $NetworkQuota 
	$OvDCParams.NicQuota = $NicQuota 
	
	$OvDCParams.UsesFastProvisioning = $FastProvision 
	$OvDCParams.OverCommitAllowed = $OverCommitAllowed 
	$OvDCParams.IsThinProvision = $ThinProvisioned 
	
	$ProviderVDCStorageProfiles = $ProviderVDC.ExtensionData.StorageProfiles.ProviderVdcStorageProfile
	$SelectedProviderVDCStorageProfiles = $ProviderVDCStorageProfiles | where {$OvDCStoragePolicyNames -contains $_.name}
	ForEach ($SelectedPvDCStorageProfile in $SelectedProviderVDCStorageProfiles) {
		$OvDCStorageProfileParams = New-Object VMware.VimAutomation.Cloud.Views.VdcStorageProfileParams
		$OvDCStorageProfileRef = $SelectedPvDCStorageProfile.href
		$OvDCStorageProfileParams.ProviderVdcStorageProfile = $OvDCStorageProfileRef
		$OvDCStorageProfileParams.Limit = $OvDCStorageProfileLimit
		$OvDCStorageProfileParams.Units = "MB"
		$OvDCStorageProfileParams.Default = $true
		$OvDCStorageProfileParams.Enabled = $true
		$OvDCParams.VdcStorageProfile += $OvDCStorageProfileParams
	}
	
	$OvDCComputeCapacity = New-Object VMware.VimAutomation.Cloud.Views.ComputeCapacity
	$OvDCComputeCapacity.Cpu = New-Object VMware.VimAutomation.Cloud.Views.CapacityWithUsage
	$OvDCComputeCapacity.Memory = New-Object VMware.VimAutomation.Cloud.Views.CapacityWithUsage
	$OvDCComputeCapacity.Cpu.Allocated = $OvDCCPUAllocated
	$OvDCComputeCapacity.Cpu.Limit = $OvDCCPULimit
	$OvDCComputeCapacity.Cpu.Units = "MHz"
	$OvDCComputeCapacity.Memory.Allocated = $OvDCMemAllocated
	$OvDCComputeCapacity.Memory.Limit = $OvDCMemLimit
	$OvDCComputeCapacity.Memory.Units = "MB"
	$OvDCParams.ComputeCapacity = $OvDCComputeCapacity
	
	$Org.ExtensionData.CreateVdcsparam($OvDCParams)	
	
<#
	.SYNOPSIS

	Creates a vCloud Organization vDC 

	.DESCRIPTION

	Creates an Organization vDC on a given vCloud Director, using the vCloud API /admin/org/{id}/vdcsparams
	operation. The vCloud Orgazination and Provider vDC objects on which the OvDC will be based need to be passed as arguments.
	Consult the available parameters for more details on which properties can be specified.
	
	.PARAMETER Org
	A vCloud Director Server Organization object under which the new Org vDC will be created.
	
	.PARAMETER ProviderVDC
	A vCloud Director Server Provider vDC object which will provide the resources to be consumed by the new Org vDC.
	
	.PARAMETER OvDCName
	The name of the Org vDC to be created.
	
	.PARAMETER OvDCDescription
	The description of the Org vDC to be created.
	
	.PARAMETER AllocationModel
	The allocation model used by this vDC. One of:
	AllocationVApp (Pay as you go. Resources are committed to a vDC only when vApps are created in it. When you use this allocation model, any Limit values you specify for Memory and CPU are ignored on create and returned as 0 on retrieve.)
	AllocationPool (Only a percentage of the resources you allocate are committed to the organization vDC.)
	ReservationPool (All the resources you allocate are committed as a pool to the organization vDC. vApps in vDCs that support this allocation model can specify values for resource and limit.)  
	
	.PARAMETER OvDCStoragePolicyNames
	The name of Storage Policies that are available in the Provider vDC and should be associated with this particular Org vDC.
	
	.PARAMETER OvDCStorageProfileAllocated
	For the moment this parameter takes a single [int] value. For whichever number of specified Storage Policy names,
	said value will be set as the limit in MB for the OvDC Storage Profile. This will be changed in a future version 
	to accomodate diffrent limit values for each associated storage policy.
	
	.PARAMETER OvDCCPUAllocated
	Allocated CPU resources to the Org vDC (in MHz).
	   
	.PARAMETER OvDCCPULimit
	Limit of CPU resources to the Org vDC (in MHz). Can't be less than OvDCCPUAllocated. If it is greater, implies overprovisioning.

	.PARAMETER OvDCMemAllocated
	Allocated memory resources to the Org vDC (in MB).
	
	.PARAMETER OvDCMemLimit
	Limit of memory resources to the Org vDC (in MB). Can't be less than OvDCMemAllocated. If it is greater, implies overprovisioning.

	.PARAMETER GuaranteedCPU
	Percentage of allocated CPU resources guaranteed to vApps deployed in this vDC. For example, if this value is 0.75, then 75% of allocated resources are guaranteed. Required when AllocationModel is AllocationVApp or AllocationPool. Value defaults to 1.0 if the element is empty. 	

	.PARAMETER GuaranteedMem
	Percentage of allocated memory resources guaranteed to vApps deployed in this vDC. For example, if this value is 0.75, then 75% of allocated resources are guaranteed. Required when AllocationModel is AllocationVApp or AllocationPool. Value defaults to 1.0 if the element is empty. 
	
	.PARAMETER VCpuInMhz
	Specifies the clock frequency, in Megahertz, for any virtual CPU that is allocated to a VM. A VM with 2 vCPUs will consume twice as much of this value. Ignored for ReservationPool. Required when AllocationModel is AllocationVApp or AllocationPool, and may not be less than 256 MHz. Defaults to 1000 MHz if the element is empty or missing. As of API version 5.7 this element became redundant with the "VCpuInMhz2" element in VdcType. Both elements are set to the same value in responses. However, on requests this element's value is the one that's used. 
	
	.PARAMETER VMQuota
	The maximum number of VMs that can be created in this vDC. Includes deployed and undeployed VMs in vApps and vApp templates. Defaults to 0, which specifies an unlimited number. 
	
	.PARAMETER NetworkQuota
	Maximum number of network objects that can be deployed in this vDC. Defaults to 0, which means no networks can be deployed.
	
	.PARAMETER NicQuota
	Maximum number of virtual NICs allowed in this vDC. Defaults to 0, which specifies an unlimited number. 
	
	.PARAMETER FastProvision
	Boolean to request fast provisioning. Request will be honored only if the underlying datastore supports it. Fast provisioning can reduce the time it takes to create virtual machines by using vSphere linked clones. If you disable fast provisioning, all provisioning operations will result in full clones. 
	
	.PARAMETER OverCommitAllowed
	Set to false to disallow creation of the VDC if the AllocationModel is AllocationPool or ReservationPool and the ComputeCapacity (i.e. Mem/CPU allocation,limit or guaranteed values) you specified is greater than what the backing Provider VDC can supply. Defaults to true if empty or missing. 
	
	.PARAMETER ThinProvisioned
	Boolean to request thin provisioning. Request will be honored only if the underlying datastore supports it. Thin provisioning saves storage space by committing it on demand. This allows over-allocation of storage. 
	
	.OUTPUTS
	
	VMware.VimAutomation.Cloud.Views.OrgVDC. Outputs the created Organization vDC Object.
	
	.EXAMPLE

	createOrgVDC -Org (Get-Org "Org02") -ProviderVDC (Get-ProviderVDC "PvDC02") -OvDCName "OvDC02" -OvDCDescription "An OvDC" -AllocationModel "AllocationVApp" -OvDCStoragePolicyNames ("StoragePolicy-SAS","StoragePolicy-SSD") -OvDCStorageProfileLimit 512000 -OvDCCPUAllocated 5000 -OvDCMemAllocated 51200 -GuaranteedCPU 0.1 -GuaranteedMem 0.2 -VCpuInMhz 1000 -VMQuota 100 -NetworkQuota 0 -NicQuota 400 -FastProvision $true -OverCommitAllowed $true -ThinProvisioned $true
	Creates an Org vDC, on Organization "Org02", backed by Provider vDC "PvDC02", with name "OvDC02" and specified parameters. Please note that parameters OvDCCPULimit and OvDCMemLimit were not set as they would be ignored considering the allocation model selected. Consult help on AllocationModel parameter for details.
	
#>	
}

### !!! Change this function to make use of createOrgVDC						!!!
### !!! This function contains neddlessly repeated code 						!!!
function copyOrgVDC {
	Param(	   
	   [Parameter(Mandatory=$True)]
	   $DestinationOrg,
	   
	   [Parameter(Mandatory=$True)]
	   $DestinationProviderVDC,
		
	   [Parameter(Mandatory=$True)]
	   $ReferenceOrgVDC,
	   
	   [Parameter(Mandatory=$False)]
	   [string]$OvDCName,
	   
	   [Parameter(Mandatory=$False)]
	   [string]$OvDCDescription,
	   
	   [Parameter(Mandatory=$False)]
	   [Boolean]$CopyReferenceOrgVDCStorageProfiles = $true,
	   
	   [Parameter(Mandatory=$False)]
	   [int]$OvDCStorageProfileLimit = 0,
	   
	   [Parameter(Mandatory=$False)]
	   [Boolean]$FastProvision,
	   
	   [Parameter(Mandatory=$False)]
	   [Boolean]$OverCommitAllowed,
	   
	   [Parameter(Mandatory=$False)]
	   [Boolean]$ThinProvisioned
	   
	)
	
	$CIServer = getServerFromUid $DestinationOrg
	
	$OvDCParams = New-Object VMware.VimAutomation.Cloud.Views.CreateVdcParams
	
	If ($OvDCName) { $OvDCParams.Name = $OvDCName }
	Else { $OvDCParams.Name = $ReferenceOrgVDC.Name }
	If ($OvDCName) { $OvDCParams.Description = $OvDCDescription }
	Else { $OvDCParams.Description = $ReferenceOrgVDC.Description }
	$OvDCParams.AllocationModel = $ReferenceOrgVDC.ExtensionData.AllocationModel
	$OvDCParams.ProviderVdcReference = $DestinationProviderVDC.href
	$OvDCParams.IsEnabled = $DestinationProviderVDC.IsEnabled
	
	$OvDCParams.ResourceGuaranteedCpu =  $ReferenceOrgVDC.ExtensionData.ResourceGuaranteedCpu
	$OvDCParams.ResourceGuaranteedMemory = $ReferenceOrgVDC.ExtensionData.ResourceGuaranteedMemory
	If ($ReferenceOrgVDC.VMCpuCoreMHz -gt 0) { $OvDCParams.VCpuInMhz = $ReferenceOrgVDC.VMCpuCoreMHz }
	If ($ReferenceOrgVDC.VMMaxCount -gt 0) { $OvDCParams.VMQuota = $ReferenceOrgVDC.VMMaxCount }
	If ($ReferenceOrgVDC.NetworkMaxCount -gt 0) { $OvDCParams.NetworkQuota = $ReferenceOrgVDC.NetworkMaxCount }
	If ($ReferenceOrgVDC.NicMaxCount -gt 0) { $OvDCParams.NicQuota = $ReferenceOrgVDC.NicMaxCount }
	
	If ([object]::Equals($FastProvision,$null)) {
		$OvDCParams.UsesFastProvisioning = $ReferenceOrgVDC.FastProvision
	} Else { $OvDCParams.UsesFastProvisioning = $FastProvision }
	
	If ([object]::Equals($OverCommitAllowed,$null)) {
		$OvDCParams.OverCommitAllowed = $ReferenceOrgVDC.OverCommitAllowed
	} Else { $OvDCParams.OverCommitAllowed = $OverCommitAllowed }
	
	If ([object]::Equals($ThinProvisioned,$null)) {
		$OvDCParams.ThinProvisioned = $ReferenceOrgVDC.ThinProvisioned
	} Else { $OvDCParams.IsThinProvision = $ThinProvisioned }
	
	
	If ($CopyReferenceOrgVDCStorageProfiles) {
		$ReferenceOrgVDCStorageProfiles = $ReferenceOrgVDC.ExtensionData.VdcStorageProfiles.VdcStorageProfile
		$ProviderVDCStorageProfiles = $DestinationProviderVDC.ExtensionData.StorageProfiles.ProviderVdcStorageProfile
		ForEach ($storageProfile in $ReferenceOrgVDCStorageProfiles) {
			Write-Verbose $storageProfile
			$storageProfileView = Get-CIView -Id $storageProfile.href
			$OvDCStorageProfileParams = New-Object VMware.VimAutomation.Cloud.Views.VdcStorageProfileParams
			
			$PvDCStorageProfileHref = ($ProviderVDCStorageProfiles | where {$_.name -eq $storageProfile.Name}).href
			Write-Verbose "PvDC SP Href: $PvDCStorageProfileHref"
			$OvDCStorageProfileParams.ProviderVdcStorageProfile = $PvDCStorageProfileHref
			$OvDCStorageProfileParams.Limit = $storageProfileView.Limit
			$OvDCStorageProfileParams.Units = "MB"
			$OvDCStorageProfileParams.Default = $storageProfileView.Default
			$OvDCStorageProfileParams.Enabled = $storageProfileView.Enabled
			$OvDCParams.VdcStorageProfile += $OvDCStorageProfileParams
		}

		
	} Else {
		$OvDCStorageProfileParams = New-Object VMware.VimAutomation.Cloud.Views.VdcStorageProfileParams
		$OvDCStorageProfileHref = ($DestinationProviderVDC.ExtensionData.StorageProfiles.ProviderVDCStorageProfile | where {$_.name -eq "*"}).href
		$OvDCStorageProfileParams.ProviderVdcStorageProfile = $OvDCStorageProfileHref
		$OvDCStorageProfileParams.Limit = $OvDCStorageProfileLimit
		$OvDCStorageProfileParams.Units = "MB"
		$OvDCStorageProfileParams.Default = $true
		$OvDCStorageProfileParams.Enabled = $true
		$OvDCParams.VdcStorageProfile += $OvDCStorageProfileParams
	}
	
	$OvDCComputeCapacity = New-Object VMware.VimAutomation.Cloud.Views.ComputeCapacity
	$OvDCComputeCapacity.Cpu = New-Object VMware.VimAutomation.Cloud.Views.CapacityWithUsage
	$OvDCComputeCapacity.Memory = New-Object VMware.VimAutomation.Cloud.Views.CapacityWithUsage
	$OvDCComputeCapacity.Cpu.Allocated = $ReferenceOrgVDC.ExtensionData.ComputeCapacity.Cpu.Allocated
	$OvDCComputeCapacity.Cpu.Limit = $ReferenceOrgVDC.ExtensionData.ComputeCapacity.Cpu.Limit
	$OvDCComputeCapacity.Cpu.Units = "MHz"
	$OvDCComputeCapacity.Memory.Allocated =  $ReferenceOrgVDC.ExtensionData.ComputeCapacity.Memory.Allocated
	$OvDCComputeCapacity.Memory.Limit = $ReferenceOrgVDC.ExtensionData.ComputeCapacity.Memory.Limit
	$OvDCComputeCapacity.Memory.Units = "MB"
	$OvDCParams.ComputeCapacity = $OvDCComputeCapacity

	$DestinationOrg.ExtensionData.CreateVdcsparam($OvDCParams)	

	
<#
	.SYNOPSIS

	Creates a vCloud Organization vDC by copying settings from a reference Organization vDC.

	.DESCRIPTION

	Creates an Organization vDC on a given vCloud Director, using the vCloud API /admin/org/{id}/vdcsparams
	operation. The vCloud Orgazination and Provider vDC objects on which the OvDC will be based need to be passed as arguments.
	The new Organization vDC will have its confgiration based on a reference Org vDC, also passed as a parameter. 
	Other optional parameters can be set to override some specific configuration settings.
	
	.PARAMETER DestinationOrg
	A vCloud Director Server Organization object under which the new Org vDC will be created.
	
	.PARAMETER DestinationProviderVDC
	A vCloud Director Server Provider vDC object which will provide the resources to be consumed by the new Org vDC.
	
	.PARAMETER ReferenceOrgVDC
	The reference Org vDC from which the name, description, allocation model, cpu and memory resources allocation, limits and guaranteed values will be based on.
	Also uses the reference Org vDC VCpuInMhz, Enabled, UsesFastProvisioning, OverCommitAllowed, IsThinProvision and StorageProfiles properties.
	
	.PARAMETER OvDCName
	The name of the Org vDC to be created, set this if you want to override the ReferenceOrgVDC's name.
	
	.PARAMETER OvDCDescription
	The description of the Org vDC to be created, set this if you want to override the ReferenceOrgVDC's description.
	
	.PARAMETER CopyReferenceOrgVDCStorageProfiles
	Set this boolean parameter to true if you wish to use storage policies with the same name and limit values as the ones found on the reference Org vDC.
	Otherwise, set it to false to specify no associated storage policy and use the catch all "*" storage policy. Defaults to true.
	
	.PARAMETER OvDCStorageProfileLimit
	Use this parameter only if you set CopyReferenceOrgVDCStorageProfiles to false. This will set the "*" storage profile limit in MB for this Org vDC.
	
	.PARAMETER FastProvision
	Boolean to request fast provisioning. Request will be honored only if the underlying datastore supports it. Fast provisioning can reduce the time it takes to create virtual machines by using vSphere linked clones. If you disable fast provisioning, all provisioning operations will result in full clones. Don't set this parameter if you want to keep the same value as the reference Org vDC.
	
	.PARAMETER OverCommitAllowed
	Set to false to disallow creation of the VDC if the AllocationModel is AllocationPool or ReservationPool and the ComputeCapacity (i.e. Mem/CPU allocation,limit or guaranteed values) you specified is greater than what the backing Provider VDC can supply. Don't set this parameter if you want to keep the same value as the reference Org vDC.
	
	.PARAMETER ThinProvisioned
	Boolean to request thin provisioning. Request will be honored only if the underlying datastore supports it. Thin provisioning saves storage space by committing it on demand. This allows over-allocation of storage.  Don't set this parameter if you want to keep the same value as the reference Org vDC.
	
	.OUTPUTS
	
	VMware.VimAutomation.Cloud.Views.OrgVDC. Outputs the created Organization vDC Object.
	
	.EXAMPLE

	copyOrgVDC -DestinationOrg (Get-Org "Org02") -DestinationProviderVDC (Get-ProviderVDC "PvDC02") -ReferenceOrgVDC (Get-OrgVDC "OvDC01") -OvDCName "OvDC02" -OvDCDescription "Another OvDC" -CopyReferenceOrgVDCStorageProfiles $true -FastProvision $true -OverCommitAllowed $true -ThinProvisioned $true
	Creates an Org vDC, on Organization "Org02", backed by Provider vDC "PvDC02", by useing Org vDC "OvDC01" as reference, with the new name "OvDC02" and other specified parameters. Please note that the parameter OvDCStorageProfileLimit was not set as the CopyReferenceOrgVDCStorageProfiles was set to true.
	
#>
}

## This function can only create direct type OrgVDCNetworks
function createOrgVDCNetwork {
	Param(
		[Parameter(Mandatory=$True)]
		$ExternalNetwork,
		
		[Parameter(Mandatory=$True)]
		$OrgVDC,
	   
		[Parameter(Mandatory=$True)]
		[string]$OrgVDCNetworkName,
		
		[Parameter(Mandatory=$False)]
		[string]$Description,
		
		[Parameter(Mandatory=$False)]
		[Boolean]$IsShared = $false
	  
	)
	
	$OrgVDCAvaliableNetworks = GetOrgVDCAvailableNetworksFromOrgVDC -Object $OrgVDC
	If ($OrgVDCAvaliableNetworks.Name -contains $OrgVDCNetworkName) {
		Write-Host "OrgVDCNetwork with name [$($OrgVDCNetworkName)] already exists in OrgVDC [$($OrgVDC.Name)]"
		Return -1
	}
	
	$OrgVDCNetworkParams = New-Object VMware.VimAutomation.Cloud.Views.OrgVdcNetwork
	$OrgVDCNetworkParams.Name = $OrgVDCNetworkName
	$OrgVDCNetworkParams.Description = $Description
	$OrgVDCNetworkParams.IsShared = $IsShared
	
	$OrgVDCNetworkParams.Configuration =  New-Object VMware.VimAutomation.Cloud.Views.NetworkConfiguration
	$OrgVDCNetworkParams.Configuration.ParentNetwork = $ExternalNetwork.href
	$OrgVDCNetworkParams.Configuration.FenceMode = "bridged"
	
	$OrgVDC.ExtensionData.CreateNetwork($OrgVDCNetworkParams)
	
<#
	.SYNOPSIS

	Creates a vCloud Organization vDC Network based on a External Network (direct connection).

	.DESCRIPTION

	Creates an Organization vDC Network on a given vCloud Director, using the vCloud API /admin/vdc/{id}/networks
	operation. This function can only create direct connections  based on vCloud External Networks.
	
	.PARAMETER ExternalNetwork
	A vCloud Director External Network object that resides on the same vCloud environment as the Org vDC on which this network will be created.\
	This external network must be available to the Org vDC's Provider vDC.
	
	.PARAMETER OrgVDC
	A vCloud Director Server Organization vDC object on which this network will be created.
	
	.PARAMETER OrgVDCNetworkName
	The desired name of the new Org vDC Network.
	
	.PARAMETER Description
	The desired description of the new Org vDC Network.
	
	.PARAMETER IsShared
	Boolean. True if this network is shared to multiple Org vDCs. 
	
	.OUTPUTS
	
	VMware.VimAutomation.Cloud.Views.OrgVdcNetwork. Outputs the created Organization vDC Network Object.
	
	.EXAMPLE

	createOrgVDCNetwork -ExternalNetwork (Get-ExternalNetwork "Ext_net01") -OrgVDC (Get-OrgVDC "OvDC02") -OrgVDCNetworkName "Org_net01" -Description "An Org vDC Net" -IsShared $false 
	Creates an Org vDC Network, with a direct connection type based on the External Network "Ext_net01", on Org vDC "OvDC02".
	
#>
}

function copyOrgVDCNetworkFromReferenceOrgVdc {
	Param(
		[Parameter(Mandatory=$True)]
		$ReferenceOvDC,
		
		[Parameter(Mandatory=$True)]
		$OrgVDC
	)
	
	$refCIServer = GetServerFromUid -Object $ReferenceOvDC
	$destinationCIServer = GetServerFromUid -Object $OrgVDC
	
	$refAvailableNetworks = GetOrgVDCAvailableNetworksFromOrgVDC -Object $ReferenceOvDC
	ForEach ($refAvailableNetwork in $refAvailableNetworks) {
		$refOrgVDCNet = Get-CIView -Id $refAvailableNetwork.Href -Server $refCIServer

		$parentNetName = $refOrgVDCNet.Configuration.ParentNetwork.Name
		$ExternalNetwork = Get-ExternalNetwork -Name $parentNetName -Server $destinationCIServer
		
		createOrgVDCNetwork -ExternalNetwork $ExternalNetwork -OrgVDC $OrgVDC `
		 -OrgVDCNetworkName $refOrgVDCNet.Name -Description $refOrgVDCNet.Description
	}
	
<#
	.SYNOPSIS

	Creates vCloud Organization vDC Networks on a given Org vDC, based on a reference Org vDC's network.

	.DESCRIPTION

	Creates a numer of Organization vDC Network on a given vCloud Director, using the vCloud API /admin/vdc/{id}/networks
	operation. This function can only create direct connections  based on vCloud External Networks. It iterates all available networks on the reference Org vDC, and creates
	a new one on the destination Org vDC, using the same Org vDC Network name and External Networks of the same name available on the same server as the destination Org vDC. 
	
	.PARAMETER ReferenceOvDC
	A vCloud Director Org vDC object that will be used as reference for the Org vDC Networks that will be created on the parameter OrgVDC object.
	
	.PARAMETER OrgVDC
	A vCloud Director Server Organization vDC object on which the networks will be created.
	
	.OUTPUTS
	
	VMware.VimAutomation.Cloud.Views.OrgVdcNetwork. Outputs each of the created Organization vDC Network Object.
	
	.EXAMPLE

	copyOrgVDCNetworkFromReferenceOrgVdc -ReferenceOvDC (Get-OrgVDC "OvDC01" -Server "vcd-server01") -OrgVDC (Get-OrgVDC "OvDC02" -Server "vcd-server02")
	Creates a number of Org vDC Networks on Org vDC "OvDC02", using the same name and same external network names as the networks found on Org vDC "OvDC01"
	
#>
	
}
	
#WIP
function exportVAppToJSON {
	Param(
		[Parameter(Mandatory=$True,Position=1)]
		[string]$vAppName,
		
		[Parameter(Mandatory=$True)]
		[string]$SourceCI,
	   
		[Parameter(Mandatory=$False)]
		$JSONFilePath
	)

	$CIServer = $global:defaultciservers | where {$_.name -like $SourceCI}
	$vApp = Get-CIVapp -Name $vAppName -Server $CIServer
	$OvDC = Get-OrgVdc -Server $CIServer | where {($_ | Get-CIVApp).name -contains $vApp.Name}

	$objProperties = @{}
	$objProperties.vAppName = $vApp.Name
	$objProperties.vAppDescription = $vApp.Description
	$objProperties.OrgName = $vApp.Org.Name
	$objProperties.OrgVdcName = $OvDC.Name
	
	# $objProperties.vAppNetworkConfig = @() 
	$netConfigs = @()
	ForEach ($netConfig in $vApp.ExtensionData.GetNetworkConfigSection().NetworkConfig) {
		$netConfigProps = @{}
		$netConfigProps.NetworkName = $netConfig.NetworkName
		$netConfigProps.IsDeployed = $netConfig.IsDeployed
		$netConfigEntry = New-Object �TypeName "PSObject" �Property $netConfigProps
		$netConfigs += $netConfigEntry
	}
	# $vAppNets = New-Object �TypeName "PSObject" �Property $netConfigProps
	$objProperties.vAppNetworkConfig = $netConfigs
	
	$objProperties.VMs = @()
	ForEach ($CIVM in $vApp.ExtensionData.Children.Vm) {
		$vmProps = @{}
		$vmProps.VMName = $CIVM.Name
		$vmProps.StorageProfileName = $CIVM.StorageProfile.Name
		# might be needed to add a storage profile entry for each HD
		
		$NetConns = @()
		ForEach ($netConn in $CIVM.GetNetworkConnectionSection().NetworkConnection) {
			$netConnProps = @{}
			$netConnProps.NetworkConnectionIndex = $netConn.NetworkConnectionIndex
			$netConnProps.NetworkName = $netConn.Network
			$netConnProps.IsConnected = $netConn.IsConnected
			$netConnProps.IpAddressAllocationMode = $netConn.IpAddressAllocationMode
			$netConnProps.IpAddress = $netConn.IpAddress

			Write-Verbose "$($CIVM.Name) has a connection to: $($netConn.Network)"
			$NetConnsEntry = New-Object �TypeName "PSObject" �Property $netConnProps

			$NetConns += $NetConnsEntry
		}
		$vmProps.NetworkConnections = $NetConns
		$VMEntry = New-Object �TypeName "PSObject" �Property $vmProps
		
		$objProperties.VMs += $VMEntry
	}
	$vAppToExport = New-Object �TypeName "PSObject" �Property $objProperties

	if ($JSONFilePath) { $vAppToExport | ConvertTo-JSON -Depth 5 | Out-File $JSONFilePath }
	else { $vAppToExport | ConvertTo-JSON -Depth 5 | Out-File "./$($vApp.Name).JSON" }
	
<#
	.SYNOPSIS

	Creates text file using JSON formatting to describe relevant vCloud vApp properties.

	.DESCRIPTION

	Outputs some properties of a vCloud vApp to a JSON text file, to serve as documentation and that can also be consumed by function importVAppFromJSON.
	This text file will describe the vApp Name, Description, the name of the Organization and Org vDC on which the vApp resides.
	Also, the vApp's networks and some of each of the networks properties, its name and IsDeployed values.
	And finally, a list of the VM's that compose this vApp, and more importantly, the name of the storage profile associated with each VM,
	and data about each of the VMs connections.
	
	.PARAMETER SourceCI
	The name of a vCloud Director Server to which there is a currently active connection
	
	.PARAMETER vAppName
	The name of a vCloud vApp on the SourceCI server.
	
	.PARAMETER JSONFilePath
	The full path on which the text file will be created. If no path is specified, a .json file will be created on the current directory with the same as the exported vApp.
	
	.OUTPUTS
	
	Void. Creates a text file of a locally accessible path.
	
	.EXAMPLE

	exportVAppToJSON -vAppName "vApp01" -SourceCI "vcd-server01" -JSONFilePath "C:\vcd\vAppExports\vcd-server01\vApp01.json"
	Create a text file at the specified path, which describes specific properties and relationships if vCloud vApp "vApp01" residing on vCloud server "vcd-server01"
#>	
}

#WIP
function importVAppFromJSON {
	Param(
		[Parameter(Mandatory=$True,Position=1)]
		[string]$JSONFilePath,
		
		[Parameter(Mandatory=$True)]
		[string]$DestinationCI,
		
		[Parameter(Mandatory=$True)]
		[string]$DestinationVI
	)
	
	
	$vAppDefinition = ConvertFrom-JSON -InputObject (gc -RAW $JSONFilePath)
	write-verbose "connected to: $($global:defaultciservers)"
	write-verbose "loking for $($destinationCI)"
	$CIServer = $global:defaultciservers | where {$_.name -like $DestinationCI}
	$OvDC = Get-OrgVdc -Name $vAppDefinition.OrgVdcName -Server $CIServer
	
	$vApp = New-CIVApp -Name $vAppDefinition.vAppName -OrgVdc $OvDC -Description $vAppDefinition.vAppDescription -Server $CIServer
	
	if ($vApp.Count -ne 1) {
		Write-Host "vApp [$($vAppDefinition.vAppName)] was not properly created on OrgVDC [$($vAppDefinition.OrgVdcName)]"
		return -1
	}
	ForEach ($netConfig in $vAppDefinition.vAppNetworkConfig) {
		newvAppNetworkFromOvDCNetwork -vApp $vApp -DestinationOvDC $OvDC -OrgVDCNetworkName $netConfig.NetworkName
	}
	
	ForEach ($VM in $vAppDefinition.VMs) {
	
		Write-Host "Importing VM [$($VM.VMName)] with StorageProfile [$($VM.StorageProfileName)] into vApp [$($vAppDefinition.vAppName)] on OrgVDC [$($vAppDefinition.OrgVdcName)]"
		
		importVMIntoVApp -DestinationCIServer $DestinationCI -DestinationVIServer $DestinationVI -OrgVdcName $OvDC.Name `
		 -vAppName $vAppDefinition.vAppName -VMName $VM.VMName -VdcStorageProfile $VM.StorageProfileName -CreateVApp:$false
		
		$CIVM = $null
		$CIVM = Get-CIVM -Name $VM.VMName -OrgVDC $OvDC -Server $DestinationCI
		if ($CIVM.Count -ne 1) {
			Write-Host "VM [$($VM.VMName)] was not properly imported into vApp [$($vAppDefinition.vAppName)]"
			return -1
		}
		ForEach ($netConn in $VM.NetworkConnections) {
			Write-Verbose "$Connecting to ($netConn.NetworkName)"
			setCIVMNetworkConnection -CIVM $CIVM -NetworkConnectionIndex $netConn.NetworkConnectionIndex `
			 -NetworkToConnect $netConn.NetworkName -IpAddressAllocationMode $netConn.IpAddressAllocationMode `
			 -IsConnected [System.Convert]::ToBoolean($netConn.IsConnected) -IPAddress $netConn.IpAddress
		}	
	}
	
<#
	.SYNOPSIS

	Creates a vApp based on a JSON file that was previously generated by the exportVAppToJSON function.

	.DESCRIPTION

	Creates a vApp by reading and parsing a JSON formatted file that was generated the exportVAppToJSON function.
	This function will create the vApp on a giver vCloud server, under an Organization and Org vDC with the same name as contained on the JSON text file,
	create vApp networks based of the vApp networks described on the file and finally, import vSphere VMs based on the JSON file, while also setting their
	vCloud connections.
	It's important to notice that the imported VMs will most likely be shown as in an 'invalid' state on the vCloud Server.
	This is expected. VMs should be rectified one they are powered off through vSphere/OS.
	
	.PARAMETER JSONFilePath
	The full path on which the text file will be created. If no path is specified, a .json file will be created on the current directory with the same as the exported vApp.
	
	.PARAMETER DestinationCI
	The name of a vCloud Director Server to which there is a currently active connection.
	
	.PARAMETER DestinationVI
	The name of a vSphere vCenter Server to which there is a currently active connection and on which the VMs that will be imported onto the new vCloud vApp are running.
	
	.OUTPUTS
	Multiple. Outputs vApp objects, new vClooud vApp networks, imported vCloud VMs and created connections.
	
	.EXAMPLE

	importVAppFromJSON -JSONFilePath "C:\vcd\vAppExports\vcd-server01\vApp01.json" -DestinationCI "vcd-server02" -DestinationVI "vi-server02"
	Creates a vApp, vApp Networks, import VMs and creates VM connections, based on the file at the specified path, on the specified vCliud and vSphere servers.
#>	
	
}

function importVAppFromJSONVAppExists {
	Param(
		[Parameter(Mandatory=$True,Position=1)]
		[string]$JSONFilePath,
		
		[Parameter(Mandatory=$True)]
		[string]$DestinationCI,
		
		[Parameter(Mandatory=$True)]
		[string]$DestinationVC
	)
	
	
	$vAppDefinition = ConvertFrom-JSON -InputObject (gc -RAW $JSONFilePath)
	write-verbose "connected to: $($global:defaultciservers)"
	write-verbose "loking for $($destinationCI)"
	$ciServer = $global:defaultciservers | where {$_.name -like $DestinationCI}
	# $CIServer = $global:defaultciservers | where {$_.name -like $DestinationCI}
	$OvDC = Get-OrgVdc -Name $vAppDefinition.OrgVdcName -Server $CIServer
	
	$vApp = Get-CIVApp -Name $vAppDefinition.vAppName -Server $CIServer
	
	# if ($vApp.Count -ne 1) {
		# Write-Host "vApp [$($vAppDefinition.vAppName)] was not properly created on OrgVDC [$($vAppDefinition.OrgVdcName)]"
		# return -1
	# }
	# ForEach ($netConfig in $vAppDefinition.vAppNetworkConfig) {
		# newvAppNetworkFromOvDCNetwork -vApp $vApp -DestinationOvDC $OvDC -OrgVDCNetworkName $netConfig.NetworkName
	# }
	
	ForEach ($VM in $vAppDefinition.VMs) {
		
		Write-Host "Importing VM [$($VM.VMName)] with StorageProfile [$($VM.StorageProfileName)] into vApp [$($vAppDefinition.vAppName)] on OrgVDC [$($vAppDefinition.OrgVdcName)]"
		Write-Host "Are you sure you wish to continue?"
		$promptAnswer = read-host "Enter (Y/y) to continue or anything else to stop execution"
		If ($promptAnswer.toUpper() -ne 'Y') {
			Continue
		}
		
		importVMIntoVApp -DestinationCIServer $DestinationCI -DestinationVIServer $DestinationVC -OrgVdcName $OvDC.Name `
		 -vAppName $vAppDefinition.vAppName -VMName $VM.VMName -VdcStorageProfile $VM.StorageProfileName -CreateVApp:$false
		
		$CIVM = $null
		$CIVM = Get-CIVM -Name $VM.VMName -OrgVDC $OvDC -Server $DestinationCI
		if ($CIVM.Count -ne 1) {
			Write-Host "VM [$($VM.VMName)] was not properly imported into vApp [$($vAppDefinition.vAppName)]"
			# return -1
		}
		ForEach ($netConn in $VM.NetworkConnections) {
			setCIVMNetworkConnection -CIVM $CIVM -NetworkConnectionIndex $netConn.NetworkConnectionIndex `
			 -NetworkToConnect $netConn.NetworkName -IpAddressAllocationMode $netConn.IpAddressAllocationMode `
			 -IsConnected [System.Convert]::ToBoolean($netConn.IsConnected) -IPAddress $netConn.IpAddress
		}
		
	}
	
<#
	.SYNOPSIS

	Used for troubleshooting. Will do the same as the importVAppFromJSON except for not creating the vApp.

	.DESCRIPTION

	Used for troubleshooting. Will do the same as the importVAppFromJSON except for not creating the vApp.
	
	.PARAMETER JSONFilePath
	The full path on which the text file will be created. If no path is specified, a .json file will be created on the current directory with the same as the exported vApp.
	
	.PARAMETER DestinationCI
	The name of a vCloud Director Server to which there is a currently active connection.
	
	.PARAMETER DestinationVI
	The name of a vSphere vCenter Server to which there is a currently active connection and on which the VMs that will be imported onto the new vCloud vApp are running.
	
	.OUTPUTS
	Multiple. Outputs vApp objects, new vClooud vApp networks, imported vCloud VMs and created connections.
	
#>	
}


## Import a VC VM into a vCD vApp, optionally creating the vApp
## VdcStorageProfileRef should be a valid vCD API object of the VdcStorageProfileReference type
function importVMIntoVApp{
	Param(
	  [Parameter(Mandatory=$True)]
	   [string]$DestinationCIServer,
		
	   [Parameter(Mandatory=$True)]
	   [string]$DestinationVIServer,
	   
	   [Parameter(Mandatory=$True)]
	   [string]$OrgVdcName,
	   
	   [Parameter(Mandatory=$True)]
	   [string]$vAppName,
	   
	   [Parameter(Mandatory=$True)]
	   [string]$vmName,
	   
	   [Parameter(Mandatory=$True)]
	   [Boolean]$createVapp,
	   
	   [Parameter(Mandatory=$False)]
	   $VdcStorageProfile = $null,
	   
	   [Parameter(Mandatory=$False)]
	   [boolean]$SourceMove = $true
	)
	write-verbose "$($global:defaultciservers)"
	$ciServer = $global:defaultciservers | where {$_.name -like $DestinationCIServer}
	write-verbose "vCloud: $($ciserver.name)"
	$CIView = $ciServer.extensiondata.getextension().getVimServerReferences().VimServerReference.GetCIView()

	$viServer = $global:defaultviservers | where {$_.name -like $DestinationVIServer}
	
	$OvDC = Get-OrgVDC -Name $OrgVdcName -Server $ciServer
	#create new vapp with name $vAppName into vdc $OrgVdc
	If ($createVapp) { 
		New-CIVApp -Name $vAppName -OrgVdc $OvDC.Name -Server $ciServer
	}

	#get the vApp created into $vApp
	$vApp = Get-CIVapp -Name $vAppName -Server $ciServer

	#get vm with name $vmName
	$vm = get-vm $vmName -Server $viServer -ErrorAction SilentlyContinue
	If ($vm.count -lt 1) {$vm = get-vm "$($vmName) (*" -Server $viServer}
	ElseIf ($vm.count -gt 1) {
		Write-Host "More than one (1) VM with name [$($vmName)] was found."
		Return -1
	}
	
	Get-AdvancedSetting -Entity $vm -Name "cloud.uuid" | Remove-AdvancedSetting -Confirm:$false
	$indexOf = $vm.name.IndexOf('(')
	If ($indexOf -gt 0) {
		$vmNewName = $vm.name.Substring(0, $indexOf - 1)
		Set-VM -VM $vm -Name $vmNewName -Confirm:$false
		$vm = Get-VM -Name $vmNewName -server $viServer
	}

	#create import params
	$importParams = new-object VMware.VimAutomation.Cloud.Views.ImportVmIntoExistingVAppParams
	$importParams.SourceMove = $SourceMove
	If ($VdcStorageProfile) {
		$VdcStorageProfile = $OvDC.ExtensionData.VdcStorageProfiles.VdcStorageProfile | where {$_.name -eq "$VdcStorageProfile"}
		$importParams.VdcStorageProfile = $VdcStorageProfile.Href
	}
	$importParams.VmName = $vm.name
	$importParams.VmMoRef = $vm.Extensiondata.MoRef.Value
	$importParams.VApp = $vApp.href

	$CIView.ImportVmIntoExistingVApp($importParams)
	
<#
	.SYNOPSIS

	Imports a vSphere VM into a vCloud server's vApp.

	.DESCRIPTION

	Creates or uses an existing vCloud vApp to import a vSphere VM, using the vCloud API /admin/extension/vimServer/{id}/importVmAsVApp operation.
	The import VM will be shown as in an 'invalid' state on vCloud, until it is powered off externally.
	This function does not configure the vCloud VM connections.
	
	.PARAMETER DestinationCIServer
	The name of a vCloud Director Server to which there is a currently active connection and on which the vApp that will receive the imported VM will be created or already exists.
	
	.PARAMETER DestinationVIServer
	The name of a vSphere vCenter Server to which there is a currently active connection and on which the VM that will be imported into vCD is running.
	
	.PARAMETER OrgVdcName
	The name of the Org vDC that holds the vCD vApp on which the VM will be imported into.
	
	.PARAMETER vAppName
	The name of the vCloud vApp that will be created or already exists.
	
	.PARAMETER vmName
	The name of the vSphere VM that will be imported.
	
	.PARAMETER createVapp
	Boolean. Set it to true if you wish to create a new vCloud vApp before importing the VM. Otherwise, the vApp should already exist.
	
	.PARAMETER VdcStorageProfile
	The name of the vCD storage profile to which this VM will be associated to.
	
	.PARAMETER SourceMove
	Boolean. Defaults to true. Determines if the desired vSphere VM will be moved into the resource pool or if a clone operation will be performed.
	If the VM is powered on, and does not reside on a valid storage for the desired storage profile. The operation will fail if SourceMove is set to true.
	
	.OUTPUTS
	A vCloud VM Object.
	
	.EXAMPLE

	importVMIntoVApp -DestinationCIServer "vcd-server02" -DestinationVIServer "vi-server02" -OrgVdcName "OvDC02" -vAppName "vApp02" -vmName "VM-02" -createVapp $false -VdcStorageProfile "StoragePolicy-SAS" -SourceMove $true
	Imports the vSphere VM "VM-02" that exists on vCenter "vi-server02", into the vCloud vApp "vApp02" on vCloud server "vcd-server02".
	
#>
}

function MigrateVMHostToAnotherVCenter {
	Param(
		[Parameter(Mandatory=$true)]
		[String[]]$VMHostNames,
		
		[Parameter(Mandatory=$true)]
		[String]$DestinationVC,
		
		[Parameter(Mandatory=$true)]
		[String]$DestinationClusterName,
		
		[Parameter(Mandatory=$true)]
		[PSCredential]$RootCredential = (Get-Credential)
	)
	
	#$sourceServer = GetvCenter -viObject $VMHost
	If ($VMHostNames.count -lt 1) {Write-Host "Parameter 'VMHostNames' does not seem to contain any names"}
	ForEach ($VMHost in $VMHostNames) {
		Add-VMHost -Name $VMHost -Location $DestinationClusterName -Credential $RootCredential -Force -Server $DestinationVC -RunAsync
	}
		
}

#UNNECESSARY - Add-VDSwitchVMHost already does exactly this
function AddVMHostsToDestinationVDS {
	Param(
		[Parameter(Mandatory=$true)]
		[PSObject[]]$VMHosts,
		
		[Parameter(Mandatory=$true)]
		[PSObject]$DestinationVDS
	)
	
	Add-VDSwitchVMHost -VDSwitch $DestinationVDS -VMHost $VMHost
}

function MigrateHostToVDS {
	Param(
		[Parameter(Mandatory=$true)]
		[PSObject[]]$VMHosts,
		
		[Parameter(Mandatory=$true)]
		[PSObject[]]$ReferenceVMs,
		
		[Parameter(Mandatory=$true)]
		[PSObject]$DestinationVDS,
		
		[Parameter(Mandatory=$true)]
		[String[]]$VmnicNames,
		
		[Parameter(Mandatory=$true)]
		[String[]]$VmkernelNames,
		
		[Parameter(Mandatory=$true)]
		[String[]]$PGNames
	)
	### It is important to make sure that PGNames and vmkernelNames are in the correct order, relative to each other
	### failure to do so might add vmknernel interfaces to incorrect port groups
	
	Add-VDSwitchVMHost -VDSwitch $DestinationVDS -VMHost $VMHosts -Confirm:$false
	
	ForEach ($VMHost in $VMHosts) {
		$pnicsOnVDS = $VMHost | Get-VMHostNetworkAdapter -Name $VmnicNames
		Write-Verbose "acting on [$($pnicsOnVDS -join '|')]"
		$VMHostFirstUplinkLeg = $pnicsOnVDS[0] 
		$VMHostRemainingLegs = $pnicsOnVDS  | where {$_ -ne $pnicsOnVDS[0]}
		
		If ($VMHostRemainingLegs.count -lt 1) {
			Write-Host "No remaining vmnics can be configured as uplinks on host $($VMHost.Name). Skipping."
			Continue
		}

		$vmksOnVDS = $VMHost | Get-VMHostNetworkAdapter -name $VmkernelNames
		$pgsToMigrate = $DestinationVDS | Get-VDportgroup -Name $PGNames
		Add-VDSwitchPhysicalNetworkAdapter -VMHostPhysicalNic $VMHostFirstUplinkLeg -DistributedSwitch $DestinationVDS -VirtualNicPortgroup $pgsToMigrate -VMHostVirtualNic $vmksOnVDS -Confirm:$false
		
		ForEach ($netAdapt in ($ReferenceVMs | Get-NetworkAdapter)) {	
			$netAdaptDestination = Get-NetworkAdapter -Name $netAdapt.Name -VM $netAdapt.Parent.Name -server $vcdestino
			$pgDestination = Get-VDPortgroup -Name $netAdapt.NetworkName -server $vcdestino
			Set-NetworkAdapter -NetworkAdapter $netAdaptDestination -Portgroup $pgDestination -Confirm:$false
		}
		Add-VDSwitchPhysicalNetworkAdapter -VMHostPhysicalNic $VMHostRemainingLegs -DistributedSwitch $DestinationVDS -Confirm:$false
	}	
}

### !!! Change this function to make use of newvAppNetworkFromOvDCNetwork		!!!
### !!! This function contains neddlessly repeated code 						!!!
function copyvAppNetworks {
	Param(
		[Parameter(Mandatory=$true)]
		$DestinationvApp,
		
		[Parameter(Mandatory=$false)]
		$DestinationOvDC,
		
		[Parameter(Mandatory=$true)]
		$SourcevApp
	)
	
	$refNetConfigSection = $SourcevApp.ExtensionData.GetNetworkConfigSection()
	$destinationNetConfigSection = $DestinationvApp.ExtensionData.GetNetworkConfigSection()
	$destinationCIServer = getServerFromUid -Object $DestinationvApp
	
	If (-not $DestinationOvDC) {
		$Org = $DestinationvApp.Org
		ForEach ($OvDC in (Get-OrgVDC -Org $Org -Server $destinationCIServer)) {
			If ($OvDC.ExtensionData.ResourceEntities.ResourceEntity.Href -contains $DestinationvApp.href) {
				$DestinationOvDC = $OvDC
			}
		}
		If (-not $DestinationOvDC) {
			Write-Host "The parent OrgVDC of vApp [$($DestinationvApp.Name)] could not be determined."
			Return -1
		}
	}
	Write-Verbose "Found OrgVDC [$($DestinationOvDC.Name)]"
	
	
	ForEach ($refNetconfig in $refNetConfigSection.NetworkConfig) {
		
		If ($destinationNetConfigSection.NetworkConfig.NetworkName -notcontains $refNetconfig.NetworkName) {
			$placeholderVappNetConfig = New-Object VMware.VimAutomation.Cloud.Views.VAppNetworkConfiguration
			$placeholderVappNetConfig.NetworkName = $refNetconfig.NetworkName
			$placeholderVappNetConfig.IsDeployed = $refNetconfig.IsDeployed
			$placeholderVappNetConfig.Configuration = New-Object VMware.VimAutomation.Cloud.Views.NetworkConfiguration
			$placeholderVappNetConfig.Configuration.IpScopes = $refNetconfig.Configuration.IpScopes
			$placeholderVappNetConfig.Configuration.FenceMode = $refNetconfig.Configuration.FenceMode
			$placeholderVappNetConfig.Configuration.RetainNetInfoAcrossDeployments = $refNetconfig.Configuration.RetainNetInfoAcrossDeployments
			
			$parentNetName = $refNetconfig.Configuration.ParentNetwork.Name
			$parentNetHref = (Get-OrgVdcNetwork -OrgVDC $DestinationOvDC -Name $parentNetName -Server $destinationCIServer).Href
			$placeholderVappNetConfig.Configuration.ParentNetwork = $parentNetHref
			Write-Verbose "Found parent OrgVDCNetwork [$((Get-CIView -Id $parentNetHref).Name)]"
			$destinationNetConfigSection.NetworkConfig += $placeholderVappNetConfig
		}
	}
	
	$destinationNetConfigSection.UpdateServerData()

<#
	.SYNOPSIS

	Creates vCloud vApp Networks on a given vApp, based on a reference vApp's network.

	.DESCRIPTION

	Creates a number of vApp Networks on a given vCloud Director vApp, using the vCloud API /vApp/{id}/networkConfigSection
	operation. The same named Org vDC networks should be present on the recipient vApp Org vDC.
	
	.PARAMETER DestinationvApp
	A vCloud Director vApp object on which the vApp Networks will be configured.
	
	.PARAMETER DestinationOvDC
	A vCloud Director Server Organization vDC object. If this parameter is not specified, the function will automatically search for the vApp's Org vDC.
	
	.PARAMETER SourcevApp
	The reference vCloud Director vApp object from which the new network configurations on DestinationVApp will be based on.
	
	.OUTPUTS
	
	A vApp Network Config Section for each vApp network.
	
	.EXAMPLE

	copyvAppNetworks -DestinationvApp (Get-CIVApp "vApp02" -Server "vcd-server02") -SourcevApp (Get-CIVApp "vApp01" -Server "vcd-server01")
	Copies vApp networks from vCloud vApp "vApp01" to vCloud vApp "vApp02"
	
#>
}

function newvAppNetworkFromOvDCNetwork {
	Param(
		[Parameter(Mandatory=$true)]
		$vApp,
		
		[Parameter(Mandatory=$false)]
		$DestinationOvDC,
				
		[Parameter(Mandatory=$true)]
		$OrgVDCNetworkName
	)
	
	$destinationNetConfigSection = $vApp.ExtensionData.GetNetworkConfigSection()
	$destinationCIServer = getServerFromUid -Object $vApp
	If (-not $DestinationOvDC) {
		$Org = $vApp.Org
		ForEach ($OvDC in (Get-OrgVDC -Org $Org -Server $destinationCIServer)) {
			If ($OvDC.ExtensionData.ResourceEntities.ResourceEntity.Href -contains $vApp.href) {
				$DestinationOvDC = $OvDC
			}
		}
		If (-not $DestinationOvDC) {
			Write-Host "The parent OrgVDC of vApp [$($vApp.Name)] could not be determined."
			Return -1
		}
	}
	Write-Verbose "Found OrgVDC [$($DestinationOvDC.Name)]"
	
	$OvDCNetwork = Get-OrgVdcNetwork -Name $OrgVDCNetworkName -OrgVDC $DestinationOvDC -Server $destinationCIServer
	Write-Verbose "Found OrgVDCNetwork [$($OvDCNetwork.Name)] in OrgVDC [$($DestinationOvDC.Name)]"
			
	If ($destinationNetConfigSection.NetworkConfig.NetworkName -notcontains $OrgVDCNetworkName) {
		$placeholderVappNetConfig = New-Object VMware.VimAutomation.Cloud.Views.VAppNetworkConfiguration
		$placeholderVappNetConfig.NetworkName = $OvDCNetwork.Name
		$placeholderVappNetConfig.IsDeployed = $true
		$placeholderVappNetConfig.Configuration = New-Object VMware.VimAutomation.Cloud.Views.NetworkConfiguration
		$placeholderVappNetConfig.Configuration.IpScopes = $OvDCNetwork.ExtensionData.Configuration.IpScopes
		$placeholderVappNetConfig.Configuration.FenceMode = "bridged"
		$placeholderVappNetConfig.Configuration.RetainNetInfoAcrossDeployments = $false
		$placeholderVappNetConfig.Configuration.ParentNetwork = $OvDCNetwork.Href
		$destinationNetConfigSection.NetworkConfig += $placeholderVappNetConfig
		$destinationNetConfigSection.UpdateServerData()
	} Else {Write-Host "[$($vApp.Name)] already contains a network configuration named [$($OrgVDCNetworkName)]"}

<#
	.SYNOPSIS

	Creates vCloud vApp Network on a given vApp, based on a single Org vDC network.

	.DESCRIPTION

	Creates a single vApp Network on a given vCloud Director vApp, using the vCloud API /vApp/{id}/networkConfigSection
	operation. An appropriately named Org vDC Network shoudl exist on the Org vDC that backs this vApp.
	
	.PARAMETER vApp
	A vCloud Director vApp object on which the vApp Network will be configured.
	
	.PARAMETER DestinationOvDC
	A vCloud Director Server Organization vDC object. If this parameter is not specified, the function will automatically search for the vApp's Org vDC.
	
	.PARAMETER OrgVDCNetworkName
	The name of the Org vDC network that will be configured on the desired vCloud vApp.
	
	.OUTPUTS
	
	A vApp Network Config Section.
	
	.EXAMPLE

	newvAppNetworkFromOvDCNetwork -vApp (Get-CIVApp "vApp02" -Server "vcd-server02") -OrgVDCNetworkName "Org_net01"
	Configures a vApp network section with the Org vDC network "Org_net01"
	
#>
}

function setCIVMNetworkConnection {
	Param(
		[Parameter(Mandatory=$true)]
		$CIVM,
		
		[Parameter(Mandatory=$true)]
		[int]$NetworkConnectionIndex,
		
		[Parameter(Mandatory=$true)]
		[String]$NetworkToConnect,
		
		[Parameter(Mandatory=$true)]
		[ValidateSet("DHCP","POOL","MANUAL")]
		[String]$IpAddressAllocationMode,
		
		[Parameter(Mandatory=$false)]
		[boolean]$IsConnected = $true,
		
		[Parameter(Mandatory=$false)]
		[ipaddress]$IPAddress
	)
	
	If ($IpAddressAllocationMode -eq "MANUAL" -and -not($IPAddress)){
		Write-Host "IP Alloction mode was set to [MANUAL] but no IP was entered"
		Return -1
	}
	
	$CIVMNetworkConnectionSection  = $CIVM.ExtensionData.GetNetworkConnectionSection()
	$CIVMNetworkConnection = $CIVMNetworkConnectionSection.NetworkConnection | where {$_.NetworkConnectionIndex -eq $NetworkConnectionIndex}
	$CIVMNetworkConnection.Network = $NetworkToConnect
	$CIVMNetworkConnection.IsConnected = $IsConnected
	$CIVMNetworkConnection.IpAddressAllocationMode = $IpAddressAllocationMode
	If ($IpAddressAllocationMode -eq "MANUAL"){
		If ($IPAddress) { $CIVMNetworkConnection.IpAddress = $IpAddress } 
		Else {
			Write-Host "IP Alloction mode was set to [MANUAL] but no IP was entered"
			Return -1
		}
	}
	
	$CIVMNetworkConnectionSection.UpdateServerData()
	
	
<#
	.SYNOPSIS

	Configures a single vCloud connection on a vCloud VM.

	.DESCRIPTION

	Configures a single vCloud network connection on a specified vCloud VM, using the vCloud API /vApp/{id}/networkConnectionSection
	operation. An appropriately named Org vDC Network should exist on the Org vDC that backs this vApp.
	
	.PARAMETER CIVM
	A vCloud Director VM object on which the network connection will be configured.
	
	.PARAMETER NetworkToConnect
	The name of the vApp network to which this connection will be made to.
	
	.PARAMETER IpAddressAllocationMode
	IP address allocation mode for this connection. One of:
	POOL (A static IP address is allocated automatically from a pool of addresses.)
	DHCP (The IP address is obtained from a DHCP service.)
	MANUAL (The IP address is assigned manually in the IpAddress element.)
	NONE (No IP addressing mode specified.) 
	
	.PARAMETER IsConnected
	Boolean. Sets connection status of this VM.
	
	.PARAMETER IPAddress
	IP address assigned to this NIC. 
	
	.OUTPUTS
	
	Void. configures a vCloud VM network connection.
	
	.EXAMPLE

	setCIVMNetworkConnection -CIVM (Get-CIVM "VM-02" -Server "vcd-server02") -NetworkConnectionIndex 0 -NetworkToConnect "Org_net01" -IpAddressAllocationMode "MANUAL" -IPAddress "192.168.0.11" -IsConnected $true
	Configures vCD VM "VM-02", network interface at index 0, to connect to vApp Network "Org_net01", with IP "192.168.0.11" (Ip configuration is dependent on customization configuration).
	
#>
}

function copyCIVMNetworkConnections {
	Param(
		[Parameter(Mandatory=$true)]
		$DestinationCIVM, 
		
		[Parameter(Mandatory=$true)]
		$ReferenceCIVM
	)
	
	$ReferenceCIVMNetworkConnectionSection = $ReferenceCIVM.ExtensionData.GetNetworkConnectionSection()
	$CIVMNetworkConnectionSection = $DestinationCIVM.ExtensionData.GetNetworkConnectionSection()
	If ($ReferenceCIVMNetworkConnectionSection.NetworkConnection.Count -ne $CIVMNetworkConnectionSection.NetworkConnection.Count) {
		Write-Host "The total number of network connections on reference VM is not equal to the total number of network connections on destination VM"
		Return -1
	}
	
	ForEach ($netCon in $CIVMNetworkConnectionSection.NetworkConnection) {
		$refNetCon = $ReferenceCIVMNetworkConnectionSection.NetworkConnection | where {$_.NetworkConnectionIndex -eq $netCon.NetworkConnectionIndex}
		setCIVMNetworkConnection -CIVM $DestinationCIVM -NetworkConnectionIndex $netCon.NetworkConnectionIndex -NetworkToConnect $refNetcon.Network `
		 -IpAddressAllocationMode $refNetCon.IpAddressAllocationMode -IpAddress $refNetCon.IPAddress -IsConnected $refNetCon.IsConnected
	}

<#
	.SYNOPSIS

	Configures a number of vCloud connections on a vCloud VM, based on another reference vCloud VM.

	.DESCRIPTION

	Configures a number of vCloud network connection on a specified vCloud VM, based on another reference vCloud VM, using the vCloud API /vApp/{id}/networkConnectionSection
	operation. Appropriately named Org vDC Networks should exist on the Org vDC that backs the vApp on which the vCD VM resides.
	
	.PARAMETER DestinationCIVM
	A vCloud Director VM object on which the network connections will be configured.
	
	.PARAMETER ReferenceCIVM
	A vCloud Director VM object from which the network connections will be based from.
	
	.OUTPUTS
	
	Void. Configures vCloud VM network connections.
	
	.EXAMPLE

	copyCIVMNetworkConnections -DestinationCIVM (Get-CIVM "VM-02" -Server "vcd-server02") -ReferenceCIVM (Get-CIVM "VM-01" -Server "vcd-server01")
	Configures vCD VM "VM-02", network connections, based on the connections configured on vCloud VM "VM-01"
	
#>
}

function removeCIVMFromCIInventory {
		Param(
		[Parameter(Mandatory=$true)]
		$CIVM,
		
		[Parameter(Mandatory=$true)]
		[String]$VIServer,
		
		[Parameter(Mandatory=$false)]
		[boolean]$PowerOff = $false
	)
	
	If ($global:defaultviservers.name -notcontains $VIServer) {
		Write-Host "This session is not connected to any VIServer named [$($VIServer)]"
		Write-Host "Connected to the following VIServers:"
		($global:defaultviservers | where {$_.isconnected}).name -join " | "
		Return -1
	}
	If (-not ($global:defaultviservers| where {$_.name -eq $VIServer}).IsConnected) {
		Write-Host "Connection to VIServer named [$($VIServer)] is not alive"
		Write-Host "Currently Connected to the following VIServers:"
		($global:defaultviservers | where {$_.isconnected}).name -join " | "
		Return -1
	}
	
	$VIVM = GetVIVMFromCIVMBById -CIVM $CIVM
	If ($VIVM.Count -ne 1) {
		Write-Host "$([int]($VIVM.Count)) VM(s) were found on VIServer named [$($VIServer)]"
		($global:defaultviservers | where {$_.isconnected}).name -join " | "
		If (($CIVM.ExtensionData.Status -lt 0) -or ($CIVM.ExtensionData.Status -eq 9)) {
			Write-Host "Removing [$($CIVM.name)] from vCloud Inventory."
			$CIVM.ExtensionData.Delete()
			Return
		} Else {Return -1}
		
	} 
	
	$VIVMVMHost = $VIVM.VMHost
	$VIVMPath = $VIVM.ExtensionData.Config.Files.VMPathName
	
	If ($CIVM.ExtensionData.Status -lt 0) {$CIVM.ExtensionData.Delete()}
	Else {
		If ($PowerOff) {
			[void](Stop-CIVM -VM $CIVM -Confirm:$false -ErrorAction SilentlyContinue)
			While ((Get-CIView -Id $CIVM.href).Status -ne 8) {
				Sleep 20
				[void](Stop-CIVM -VM $CIVM -Confirm:$false -ErrorAction SilentlyContinue)
				[void](Stop-VM -VM $VIVM -Confirm:$false -ErrorAction SilentlyContinue)
			}
		} ElseIf ($CIVM.Status -ne 8) {
			Write-Host "[$($VIVM.Name)] VM is not currently powered off on VIServer: [$($VIServer)]"
			Write-Host "Either power off the VM manually or use parameter -PowerOff:$true for this function"
			Return -1
		}
		
		Remove-VM -VM $VIVM -Confirm:$false
		
		$CIVM.ExtensionData.Delete()
		
		New-VM -VMFilePath $VIVMPath -VMHost $VIVMVMHost -Server $VIServer
	}
	
<#
	.SYNOPSIS

	Used for troubleshooting. Helps removing a VM from vCloud without destroying it on vSphere.

	.DESCRIPTION

	Used for troubleshooting. Removes a VM from vSphere inventory (not deleting disks) to enable it to be deleted in vCD and then
	re-registered into vSphere.
	
	.PARAMETER CIVM
	vCloud VM object
	
	.PARAMETER VIServer
	vSphere vCenter server on which the VM resides.
	
	.PARAMETER PowerOff
	Boolean. If true it will power off the virtual machine before trying to remove it from the inventory. Otherwise, the VM needs to already be powered off.
	
	.OUTPUTS
	Multiple.
	
#>
}

Export-ModuleMember "Get*"
Export-ModuleMember "Create*"
Export-ModuleMember "Add*"
Export-ModuleMember "Copy*"
Export-ModuleMember "Migrate*"
Export-ModuleMember "Export*"
Export-ModuleMember "Import*"
Export-ModuleMember "Prepare*"
Export-ModuleMember "Set*"
Export-ModuleMember "Remove*"
Export-ModuleMember "New*"