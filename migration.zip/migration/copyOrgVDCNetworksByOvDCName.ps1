[CmdletBinding()]
Param(
	[Parameter(Mandatory=$true)]
	[string]$SourceCI,
	
	[Parameter(Mandatory=$true)]
	[string]$DestinationCI,
	
	[Parameter(Mandatory=$true)]
	[string]$OrgVDCName
)

$refOrgVDC = Get-OrgVDC -Name $OrgVDCName -Server $SourceCI
$destinationOrgVDC = Get-OrgVDC -Name $OrgVDCName -Server $DestinationCI

copyOrgVDCNetworkFromReferenceOrgVdc -ReferenceOvDC $refOrgVDC -OrgVDC $destinationOrgVDC