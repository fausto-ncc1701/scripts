[CmdletBinding()]
Param(
	[Parameter(Mandatory=$true)]
	[string]$SourceCI,
	
	[Parameter(Mandatory=$true)]
	[string]$DestinationCI,
	
	[Parameter(Mandatory=$true)]
	[string[]]$OrgVDCNames,
	
	[Parameter(Mandatory=$true)]
	[string]$DestinationOrgName,
	
	[Parameter(Mandatory=$true)]
	[string]$DestinationProviderVDCName
)

$DestinationProviderVDC = Get-ProviderVDC -Name $DestinationProviderVDCName -Server $DestinationCI
$DestinationOrg = get-Org -Name $DestinationOrgName -Server $DestinationCI

ForEach ($OrgVDCName in $OrgVDCNames) {
	
	$RefOvDC = Get-OrgVDC -Name $OrgVDCName -Server $SourceCI
	
	copyOrgVDC -DestinationOrg $DestinationOrg -DestinationProviderVDC $DestinationProviderVDC -ReferenceOrgVDC $RefOvDC
}