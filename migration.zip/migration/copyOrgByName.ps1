[CmdletBinding()]
Param(
	[Parameter(Mandatory=$true)]
	[string]$SourceCI,
	
	[Parameter(Mandatory=$true)]
	[string]$DestinationCI,
	
	[Parameter(Mandatory=$true)]
	[string]$OrgName
)

$refOrg = Get-Org -Name $OrgName -Server $SourceCI

copyOrg -ReferenceOrg $refOrg -DestinationCI $DestinationCI