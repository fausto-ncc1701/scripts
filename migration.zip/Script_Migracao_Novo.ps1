﻿# Script da VMware com as Funções utilizadas na Migração
import-module Z:\Scripts\migration\migrationFunctions\migrationFunctions.psm1

# Recebendo os Valores necessários para migração
$vcorig = Read-Host "vCenter de Origem"
$vcdest = Read-Host "vCenter de Destino"
$myCluster = Read-Host "Cluster de Origem"
$credroot = Get-Credential -Message "ESXi Host Credential" -UserName root
$destContainer = Read-Host "Datacenter de Destino"
$numVDS = Read-Host "Quantos vDSes existem no Cluster [$($myCluster)] a ser Migrado?"
foreach ($i in 1..$numVDS) {
 $VDStemp = Read-Host "Informe o NOME do VDS #$($i)"
 [array]$myVDS += [string]$VDStemp
}
$PathName = Read-Host "Informe o Diretório (i.e.: C:\VDSExport) para salvar backup dos vDSes"

# Realizando algumas validações
if (-Not (Test-Path $PathName)) {
  New-Item -Path $PathName -ItemType Directory
  if ((Test-Path $PathName)) {
   Write-Host "Diretório [$($PathName)] criado com sucesso"
   $exportPath = $PathName
  } else {
   Throw "Erro criando o diretório [$($PathName)]"
  }
} else {
 Write-Host "Diretório [$($PathName)] já existe. Proseguindo..."
}


if ((Get-PowerCLIConfiguration -Scope User).DefaultVIServerMode -ne "Multiple") {
    Write-Host "Preparando PowerShell User Scope for Multiple vCenters"
    Set-PowerCLIConfiguration -DefaultVIServerMode Multiple
}

#Conectando os vCenters de Origem e Destino

#$credvc = Get-Credential
Connect-VIServer -Server $vcorig 
Connect-VIServer -Server $vcdest 

#Validando se conectou nos 2

if ($global:DefaultVIServers.Count -ne 2) {
    Throw "Você não está conectado em 2 vCenters"
}

# Finalmente executando o Script

Z:\Scripts\migration\ClusterMigrationOchestration.ps1 -SourceVC $vcorig -DestinationVC $vcdest -ClusterName $myCluster -RootCredential $credroot -DestinationContainer $destContainer -VDSToMigrateNames $MyVDS -CreateVDSOnDestination:$true -KeepVDSIdentifiers:$true -VDSExportPath $exportPath